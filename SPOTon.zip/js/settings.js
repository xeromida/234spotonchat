/**
 * SPOTon Chat - Settings & Privacy Service (Supabase Edition)
 * 
 * Manages user privacy settings ('who_can_find_me', 'allow_message_requests')
 * in the Supabase 'profiles' table.
 */

const SettingsService = {
  /**
   * Retrieves privacy settings for current user
   */
  async getPrivacySettings(userId) {
    const { data: user, error } = await window.supabaseClient
      .from("profiles")
      .select("who_can_find_me, allow_message_requests")
      .eq("id", userId)
      .single();

    if (error || !user) throw new Error("User profile not found.");

    return {
      who_can_find_me: user.who_can_find_me || "everyone",
      allow_message_requests: user.allow_message_requests !== false
    };
  },

  /**
   * Updates privacy settings in Supabase
   */
  async updatePrivacySettings(userId, { whoCanFindMe, allowMessageRequests }) {
    if (whoCanFindMe && !["everyone", "nobody"].includes(whoCanFindMe)) {
      throw new Error("Invalid option for 'Who can find me'.");
    }

    const { error } = await window.supabaseClient
      .from("profiles")
      .update({
        who_can_find_me: whoCanFindMe || "everyone",
        allow_message_requests: !!allowMessageRequests
      })
      .eq("id", userId);

    if (error) {
      throw new Error(error.message || "Failed to update privacy settings.");
    }

    return await this.getPrivacySettings(userId);
  }
};

window.SettingsService = SettingsService;
