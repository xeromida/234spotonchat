/**
 * SPOTon Chat - Supabase Client Layer
 * 
 * Supports:
 * 1. Live Supabase Connection via official @supabase/supabase-js library
 * 2. High-fidelity Educational Supabase Local Emulator (Zero-Setup Mode)
 *    which implements identical Supabase SDK syntax (.from().select().eq(),
 *    .insert(), .update(), .auth.signUp(), .storage.from().upload(), etc.)
 *    backed by persistent storage and pre-seeded demonstration data.
 */

class SupabaseStorageBucketMock {
  constructor(bucketName) {
    this.bucketName = bucketName;
  }

  async upload(path, file) {
    // Read file as Data URL
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Failed to read image file."));
      reader.readAsDataURL(file);
    });

    const storageKey = `supabase_storage_${this.bucketName}_${path}`;
    localStorage.setItem(storageKey, dataUrl);

    return { data: { path }, error: null };
  }

  getPublicUrl(path) {
    const storageKey = `supabase_storage_${this.bucketName}_${path}`;
    const data = localStorage.getItem(storageKey);
    return { data: { publicUrl: data || "assets/default-avatar.svg" } };
  }
}

class SupabaseQueryBuilderMock {
  constructor(tableName, db) {
    this.tableName = tableName;
    this.db = db;
    this.filters = [];
    this.sortField = null;
    this.sortAscending = true;
    this.limitCount = null;
    this.isSingle = false;
  }

  select(columns = "*") {
    this.columns = columns;
    return this;
  }

  eq(field, value) {
    this.filters.push(item => item[field] === value);
    return this;
  }

  neq(field, value) {
    this.filters.push(item => item[field] !== value);
    return this;
  }

  ilike(field, pattern) {
    // Convert SQL ILIKE %term% to regex
    const clean = pattern.replace(/%/g, ".*");
    const regex = new RegExp(clean, "i");
    this.filters.push(item => regex.test(String(item[field] || "")));
    return this;
  }

  in(field, array) {
    this.filters.push(item => array.includes(item[field]));
    return this;
  }

  or(conditionStr) {
    // Simple mock for "field.eq.val,field2.eq.val"
    const parts = conditionStr.split(",");
    this.filters.push(item => {
      return parts.some(part => {
        const [field, op, val] = part.split(".");
        if (op === "eq") return item[field] === val;
        return false;
      });
    });
    return this;
  }

  order(field, { ascending = true } = {}) {
    this.sortField = field;
    this.sortAscending = ascending;
    return this;
  }

  limit(count) {
    this.limitCount = count;
    return this;
  }

  single() {
    this.isSingle = true;
    return this;
  }

  async then(resolve, reject) {
    try {
      let items = this.db.getTable(this.tableName);

      // Apply filters
      for (const filter of this.filters) {
        items = items.filter(filter);
      }

      // Apply sorting
      if (this.sortField) {
        items.sort((a, b) => {
          const valA = a[this.sortField];
          const valB = b[this.sortField];
          if (valA < valB) return this.sortAscending ? -1 : 1;
          if (valA > valB) return this.sortAscending ? 1 : -1;
          return 0;
        });
      }

      // Apply limit
      if (this.limitCount) {
        items = items.slice(0, this.limitCount);
      }

      const result = this.isSingle ? (items[0] || null) : items;
      resolve({ data: JSON.parse(JSON.stringify(result)), error: null });
    } catch (err) {
      resolve({ data: null, error: err });
    }
  }

  async insert(recordOrRecords) {
    try {
      const records = Array.isArray(recordOrRecords) ? recordOrRecords : [recordOrRecords];
      const items = this.db.getTable(this.tableName);

      const inserted = records.map(r => {
        const copy = { ...r };
        if (!copy.id) {
          copy.id = CryptoUtils.generateObjectId(); // UUID equivalent
        }
        if (!copy.created_at) {
          copy.created_at = new Date().toISOString();
        }
        return copy;
      });

      items.push(...inserted);
      this.db.saveTable(this.tableName, items);

      // Broadcast changes to realtime subscribers
      inserted.forEach(item => {
        this.db.broadcastChange(this.tableName, "INSERT", item);
      });

      const res = Array.isArray(recordOrRecords) ? inserted : inserted[0];
      return { data: res, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  }

  async update(updateFields) {
    try {
      const items = this.db.getTable(this.tableName);
      let modified = [];

      for (let i = 0; i < items.length; i++) {
        const match = this.filters.every(filter => filter(items[i]));
        if (match) {
          items[i] = { ...items[i], ...updateFields, updated_at: new Date().toISOString() };
          modified.push(items[i]);
          this.db.broadcastChange(this.tableName, "UPDATE", items[i]);
        }
      }

      this.db.saveTable(this.tableName, items);
      return { data: modified, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  }

  async delete() {
    try {
      let items = this.db.getTable(this.tableName);
      const remaining = [];
      const deleted = [];

      for (const item of items) {
        const match = this.filters.every(filter => filter(item));
        if (match) {
          deleted.push(item);
          this.db.broadcastChange(this.tableName, "DELETE", item);
        } else {
          remaining.push(item);
        }
      }

      this.db.saveTable(this.tableName, remaining);
      return { data: deleted, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  }
}

class SupabaseClientMock {
  constructor() {
    this.prefix = "spoton_sb_";
    this.subscribers = [];
    this.storage = {
      from: (bucket) => new SupabaseStorageBucketMock(bucket)
    };
    this.auth = {
      signUp: async ({ email, password, options = {} }) => {
        const username = options.data?.username;
        const displayName = options.data?.display_name || username;
        const userId = CryptoUtils.generateObjectId();

        const user = {
          id: userId,
          email,
          user_metadata: { username, display_name: displayName }
        };

        const session = {
          access_token: CryptoUtils.generateToken(),
          user
        };

        localStorage.setItem(window.CONFIG.SESSION_STORAGE_KEY, JSON.stringify(session));

        // Create profile record
        const nowIso = new Date().toISOString();
        const profile = {
          id: userId,
          username: username,
          username_lower: username.toLowerCase(),
          display_name: displayName,
          avatar_url: "",
          bio: "Hey there! I am using SPOTon Chat.",
          current_status: "Available",
          status_updated_at: nowIso,
          who_can_find_me: "everyone",
          allow_message_requests: true,
          username_changes_count: 0,
          last_username_change: null,
          last_seen: nowIso,
          created_at: nowIso
        };

        await this.from("profiles").insert(profile);

        return { data: { user, session }, error: null };
      },

      signInWithPassword: async ({ email, password }) => {
        const sessionRaw = localStorage.getItem(window.CONFIG.SESSION_STORAGE_KEY);
        // Find profile by email (username@spotonchat.com)
        const username = email.split("@")[0].toLowerCase();
        const { data: profile } = await this.from("profiles")
          .eq("username_lower", username)
          .single();

        if (!profile) {
          return { data: null, error: new Error("User not found or incorrect credentials.") };
        }

        const user = {
          id: profile.id,
          email,
          user_metadata: { username: profile.username, display_name: profile.display_name }
        };

        const session = {
          access_token: CryptoUtils.generateToken(),
          user
        };

        localStorage.setItem(window.CONFIG.SESSION_STORAGE_KEY, JSON.stringify(session));
        return { data: { user, session }, error: null };
      },

      signOut: async () => {
        localStorage.removeItem(window.CONFIG.SESSION_STORAGE_KEY);
        localStorage.removeItem(window.CONFIG.CURRENT_USER_KEY);
        return { error: null };
      },

      getSession: async () => {
        const raw = localStorage.getItem(window.CONFIG.SESSION_STORAGE_KEY);
        if (!raw) return { data: { session: null }, error: null };
        try {
          return { data: { session: JSON.parse(raw) }, error: null };
        } catch {
          return { data: { session: null }, error: null };
        }
      },

      getUser: async () => {
        const { data } = await this.auth.getSession();
        return { data: { user: data.session ? data.session.user : null }, error: null };
      }
    };

    this.ensureDemoSeed();
  }

  from(tableName) {
    return new SupabaseQueryBuilderMock(tableName, this);
  }

  channel(channelName) {
    const self = this;
    const channelObj = {
      name: channelName,
      handlers: [],
      presenceMap: new Map(),
      on: function(event, filterOrCallback, maybeCallback) {
        let filter = null;
        let callback = filterOrCallback;
        if (typeof filterOrCallback === "object") {
          filter = filterOrCallback;
          callback = maybeCallback;
        } else if (typeof filterOrCallback === "string") {
          filter = { event: filterOrCallback };
          callback = maybeCallback;
        }
        this.handlers.push({ event, filter, callback });
        return this;
      },
      track: async function(presenceData) {
        if (presenceData && presenceData.user_id) {
          this.presenceMap.set(presenceData.user_id, presenceData);
          self.broadcastPresence(this.name, "join", presenceData.user_id, [presenceData]);
        }
        return "ok";
      },
      untrack: async function() {
        return "ok";
      },
      presenceState: function() {
        const state = {};
        for (const [key, val] of this.presenceMap.entries()) {
          state[key] = [val];
        }
        return state;
      },
      subscribe: function(callback) {
        self.subscribers.push(this);
        if (callback) {
          setTimeout(() => callback("SUBSCRIBED"), 10);
        }
        return this;
      },
      unsubscribe: function() {
        const idx = self.subscribers.indexOf(this);
        if (idx !== -1) self.subscribers.splice(idx, 1);
      }
    };
    return channelObj;
  }

  broadcastPresence(channelName, eventType, key, presences) {
    for (const sub of this.subscribers) {
      if (sub.name === channelName) {
        for (const h of sub.handlers) {
          if (h.event === "presence" && h.filter && h.filter.event === eventType) {
            h.callback({ key, newPresences: presences, leftPresences: presences });
          }
        }
      }
    }
  }

  broadcastChange(tableName, eventType, newRecord) {
    for (const sub of this.subscribers) {
      for (const h of sub.handlers) {
        if (h.filter && h.filter.table === tableName) {
          h.callback({
            eventType,
            new: newRecord,
            old: eventType === "DELETE" ? newRecord : null
          });
        }
      }
    }
  }

  getTable(tableName) {
    const raw = localStorage.getItem(this.prefix + tableName);
    return raw ? JSON.parse(raw) : [];
  }

  saveTable(tableName, data) {
    localStorage.setItem(this.prefix + tableName, JSON.stringify(data));
  }

  ensureDemoSeed() {
    const profiles = this.getTable("profiles");
    if (profiles.length > 0) return;

    const demoProfiles = [
      {
        id: "10000000-0000-0000-0000-000000000001",
        username: "alvis",
        username_lower: "alvis",
        display_name: "Alvis Dev",
        avatar_url: "",
        bio: "Exploring Supabase & Vanilla JS chat architecture 🚀",
        current_status: "lagi belajar coding 😭",
        status_updated_at: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        who_can_find_me: "everyone",
        allow_message_requests: true,
        username_changes_count: 1,
        last_username_change: new Date(Date.now() - 4 * 86400000).toISOString(),
        last_seen: new Date().toISOString(),
        created_at: new Date(Date.now() - 30 * 86400000).toISOString()
      },
      {
        id: "10000000-0000-0000-0000-000000000002",
        username: "siti",
        username_lower: "siti",
        display_name: "Siti Rahma",
        avatar_url: "",
        bio: "Web design lover & coffee addict ☕",
        current_status: "Coffee time! ☕✨",
        status_updated_at: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        who_can_find_me: "everyone",
        allow_message_requests: true,
        username_changes_count: 0,
        last_username_change: null,
        last_seen: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        created_at: new Date(Date.now() - 20 * 86400000).toISOString()
      },
      {
        id: "10000000-0000-0000-0000-000000000003",
        username: "budi",
        username_lower: "budi",
        display_name: "Budi Santoso",
        avatar_url: "",
        bio: "Private mode active. Ping me if urgent.",
        current_status: "AFK / Do Not Disturb 🔕",
        status_updated_at: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
        who_can_find_me: "everyone",
        allow_message_requests: true,
        username_changes_count: 3,
        last_username_change: new Date(Date.now() - 1 * 86400000).toISOString(), // Cooldown active!
        last_seen: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
        created_at: new Date(Date.now() - 10 * 86400000).toISOString()
      }
    ];
    this.saveTable("profiles", demoProfiles);

    const demoConv = {
      id: "20000000-0000-0000-0000-000000000010",
      participant_one: "10000000-0000-0000-0000-000000000001",
      participant_two: "10000000-0000-0000-0000-000000000002",
      status: "active",
      request_initiator_id: "10000000-0000-0000-0000-000000000001",
      request_recipient_id: "10000000-0000-0000-0000-000000000002",
      unknown_message_count: 0,
      last_message_content: "iya wkwkwk",
      last_message_sender_id: "10000000-0000-0000-0000-000000000002",
      last_message_timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
      created_at: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
      updated_at: new Date(Date.now() - 2 * 60 * 1000).toISOString()
    };
    this.saveTable("conversations", [demoConv]);

    const msg1Id = "30000000-0000-0000-0000-000000000021";
    const demoMessages = [
      {
        id: msg1Id,
        conversation_id: demoConv.id,
        sender_id: "10000000-0000-0000-0000-000000000001",
        content: "udah makan?",
        reply_to_message_id: null,
        reply_to_sender_name: null,
        reply_to_snippet: null,
        status: "read",
        created_at: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        read_at: new Date(Date.now() - 4 * 60 * 1000).toISOString()
      },
      {
        id: "30000000-0000-0000-0000-000000000022",
        conversation_id: demoConv.id,
        sender_id: "10000000-0000-0000-0000-000000000002",
        content: "iya wkwkwk",
        reply_to_message_id: msg1Id,
        reply_to_sender_name: "alvis",
        reply_to_snippet: "udah makan?",
        status: "read",
        created_at: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
        read_at: new Date(Date.now() - 2 * 60 * 1000).toISOString()
      }
    ];
    this.saveTable("messages", demoMessages);
  }
}

// Initialize Supabase Client (Live or Educational Mock)
function initSupabaseClient() {
  const cfg = window.CONFIG.SUPABASE;
  if (cfg.USE_LIVE_SUPABASE && window.supabase && cfg.URL && !cfg.URL.includes("your-project-id")) {
    try {
      // Auto-sanitize URL to prevent "Invalid path specified in request URL" errors
      let cleanUrl = cfg.URL.trim();
      cleanUrl = cleanUrl.replace(/\/rest\/v1\/?$/i, "");
      cleanUrl = cleanUrl.replace(/\/auth\/v1\/?$/i, "");
      cleanUrl = cleanUrl.replace(/\/+$/, "");

      console.log("Initializing live Supabase connection to:", cleanUrl);
      return window.supabase.createClient(cleanUrl, cfg.ANON_KEY.trim());
    } catch (e) {
      console.warn("Could not connect to live Supabase, falling back to educational client:", e);
      return new SupabaseClientMock();
    }
  }
  return new SupabaseClientMock();
}

window.supabaseClient = initSupabaseClient();
