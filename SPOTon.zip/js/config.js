/**
 * SPOTon Chat - Configuration (Supabase Edition)
 * 
 * For local development, Supabase connection details can be configured here.
 * When deploying to hosting platforms such as Vercel, move these to environment
 * variables (e.g. NEXT_PUBLIC_SUPABASE_URL or VITE_SUPABASE_URL).
 * 
 * SECURITY NOTE:
 * - The `ANON_KEY` is a public key intended for browser clients. It is safe
 *   to expose because data access is protected by Row Level Security (RLS).
 * - NEVER expose the `SERVICE_ROLE_KEY` in frontend code!
 */

const CONFIG = {
  // Application Information
  APP_NAME: "SPOTon Chat",
  APP_TAGLINE: "Connect. Chat. Stay in touch.",
  VERSION: "2.0.0 (Supabase)",

  // =========================================================================
  // SUPABASE CONFIGURATION
  // =========================================================================
  // Set your Supabase project URL and anon public key below.
  // When USE_LIVE_SUPABASE is false or keys are empty, the app runs in
  // Zero-Setup Educational Mode with full Supabase API compatibility.
  SUPABASE: {
    USE_LIVE_SUPABASE: true, // Set to true after pasting your project credentials
    URL: "https://isiugdykpydrqbofsbnh.supabase.co", // Root Supabase Project URL (no /rest/v1)
    ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzaXVnZHlrcHlkcnFib2ZzYm5oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk3MTA0NjMsImV4cCI6MjEwNTI4NjQ2M30.mKzfCVp1WhP0Qg10zQ-GMixcefRSvG-YTFF3z5iSg2c",      // Replace with your Supabase Public Anon Key
    STORAGE_BUCKET: "avatars"                   // Supabase Storage bucket for profile pictures
  },

  // =========================================================================
  // EDUCATIONAL BUSINESS RULES (Enforced in Database & Service Layer)
  // =========================================================================
  RULES: {
    // Unknown users messaging restriction (Section 11 & 12)
    UNKNOWN_USER_MESSAGE_LIMIT: 3,

    // Username change limits (Section 10)
    MAX_USERNAME_CHANGES: 3,
    USERNAME_CHANGE_COOLDOWN_DAYS: 3,

    // Presence & Online status (Section 16)
    ONLINE_THRESHOLD_SECONDS: 120, // 2 minutes without heartbeat = offline
    POLL_INTERVAL_MS: 3000,        // Poll fallback for message updates
    HEARTBEAT_INTERVAL_MS: 30000,  // Presence heartbeat interval (30 seconds)

    // Media & Uploads (Section 9)
    MAX_AVATAR_SIZE_BYTES: 2 * 1024 * 1024, // 2MB maximum
    ALLOWED_IMAGE_TYPES: ["image/jpeg", "image/png", "image/webp", "image/gif"]
  },

  // Session storage keys
  SESSION_STORAGE_KEY: "spoton_supabase_session",
  CURRENT_USER_KEY: "spoton_current_profile"
};

// Export to window
window.CONFIG = CONFIG;
