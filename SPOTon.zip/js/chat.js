/**
 * SPOTon Chat - Chat & Messaging Service (Supabase Edition)
 * 
 * Manages:
 * - 1-on-1 conversations via Supabase 'conversations' table
 * - Supabase Realtime message subscriptions for instant chat delivery
 * - Message replies and visual quote previews
 * - Read receipts (Sent ✓, Delivered ✓✓, Read ✓✓)
 * - Unknown user 3-message gate & approval requests (Section 11 & 12)
 */

const ChatService = {
  realtimeChannel: null,

  /**
   * Initializes Supabase Realtime subscription on the 'messages' table
   */
  initRealtime(onNewMessageCallback) {
    if (this.realtimeChannel) return;

    this.realtimeChannel = window.supabaseClient
      .channel("public-messages")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "messages" },
        (payload) => {
          if (onNewMessageCallback) {
            onNewMessageCallback(payload);
          }
        }
      )
      .subscribe();
  },

  /**
   * Retrieves or creates a conversation between two users
   */
  async getOrCreateConversation(currentUserId, targetUserId) {
    if (currentUserId === targetUserId) {
      throw new Error("You cannot start a conversation with yourself.");
    }

    // Query existing conversation FIRST so previous conversations remain accessible even when blocked
    const { data: existingConvs } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .or(`participant_one.eq.${currentUserId},participant_two.eq.${currentUserId}`);

    const existing = (existingConvs || []).find(
      c => (c.participant_one === targetUserId || c.participant_two === targetUserId)
    );

    if (existing) {
      return this.formatConversation(existing);
    }

    // If starting a BRAND NEW conversation, check blocks
    const { data: targetBlockedMe } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", targetUserId)
      .eq("blocked_id", currentUserId)
      .single();

    if (targetBlockedMe) {
      throw new Error("You cannot message this user. They have blocked you.");
    }

    const { data: iBlockedTarget } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", currentUserId)
      .eq("blocked_id", targetUserId)
      .single();

    if (iBlockedTarget) {
      throw new Error("You have blocked this user. Unblock them first to message.");
    }

    // Check target user's privacy settings
    const { data: targetUser } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", targetUserId)
      .single();

    if (!targetUser) throw new Error("Target user not found.");

    // If new conversation: check target's message requests setting
    if (targetUser.allow_message_requests === false) {
      throw new Error("This user does not accept message requests from new contacts.");
    }

    // Create new conversation in "pending_request" state
    const nowIso = new Date().toISOString();
    const newConv = {
      participant_one: currentUserId,
      participant_two: targetUserId,
      status: "pending_request",
      request_initiator_id: currentUserId,
      request_recipient_id: targetUserId,
      unknown_message_count: 0,
      last_message_content: null,
      last_message_sender_id: null,
      last_message_timestamp: null,
      created_at: nowIso,
      updated_at: nowIso
    };

    const { data: inserted, error } = await window.supabaseClient
      .from("conversations")
      .insert(newConv);

    if (error) {
      throw new Error(error.message || "Failed to create conversation.");
    }

    return this.formatConversation(inserted);
  },

  /**
   * Retrieves all conversations for current user with partner details, unread counts, and block state
   */
  async getUserConversations(currentUserId) {
    const { data: convs, error } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .or(`participant_one.eq.${currentUserId},participant_two.eq.${currentUserId}`)
      .order("updated_at", { ascending: false });

    if (error || !convs) return [];

    // Query active blocks for current user
    const { data: myBlocks } = await window.supabaseClient
      .from("blocks")
      .select("blocked_id")
      .eq("blocker_id", currentUserId);

    const { data: partnerBlocks } = await window.supabaseClient
      .from("blocks")
      .select("blocker_id")
      .eq("blocked_id", currentUserId);

    const myBlockedSet = new Set((myBlocks || []).map(b => b.blocked_id));
    const partnerBlockedSet = new Set((partnerBlocks || []).map(b => b.blocker_id));

    const detailedList = [];
    for (const conv of convs) {
      const partnerId = conv.participant_one === currentUserId ? conv.participant_two : conv.participant_one;
      const { data: partner } = await window.supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", partnerId)
        .single();

      if (!partner) continue;

      // Seed presence cache for partner
      if (window.PresenceManager) {
        window.PresenceManager.cacheUserPresence(partnerId, partner.last_seen);
      }

      // Count unread messages
      const { data: unreadMsgs } = await window.supabaseClient
        .from("messages")
        .select("id")
        .eq("conversation_id", conv.id)
        .eq("sender_id", partnerId)
        .neq("status", "read");

      const isBlockedByMe = myBlockedSet.has(partnerId);
      const isBlockedByPartner = partnerBlockedSet.has(partnerId);

      const formatted = this.formatConversation(conv);
      detailedList.push({
        ...formatted,
        partner: {
          _id: partner.id,
          username: partner.username,
          display_name: partner.display_name,
          avatar_url: partner.avatar_url || "assets/default-avatar.svg",
          last_seen: partner.last_seen,
          is_online: UserService.isUserOnline(partner.last_seen),
          last_seen_text: UserService.formatLastSeen(partner.last_seen)
        },
        unread_count: (unreadMsgs || []).length,
        is_blocked_by_me: isBlockedByMe,
        is_blocked_by_partner: isBlockedByPartner,
        is_blocked: isBlockedByMe || isBlockedByPartner,
        is_pending_incoming: conv.status === "pending_request" && conv.request_recipient_id === currentUserId,
        is_pending_outgoing: conv.status === "pending_request" && conv.request_initiator_id === currentUserId
      });
    }

    return detailedList;
  },

  /**
   * Retrieves pending incoming message requests
   */
  async getPendingRequests(currentUserId) {
    const { data: list, error } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .eq("status", "pending_request")
      .eq("request_recipient_id", currentUserId)
      .order("updated_at", { ascending: false });

    if (error || !list) return [];

    const detailedList = [];
    for (const conv of list) {
      const { data: sender } = await window.supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", conv.request_initiator_id)
        .single();

      if (!sender) continue;

      const formatted = this.formatConversation(conv);
      detailedList.push({
        ...formatted,
        sender: {
          _id: sender.id,
          username: sender.username,
          display_name: sender.display_name,
          avatar_url: sender.avatar_url || "assets/default-avatar.svg",
          bio: sender.bio || ""
        }
      });
    }

    return detailedList;
  },

  /**
   * Recipient accepts a pending message request
   */
  async acceptRequest(conversationId, currentUserId) {
    const { data: conv } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .eq("id", conversationId)
      .single();

    if (!conv) throw new Error("Conversation not found.");
    if (conv.request_recipient_id !== currentUserId) {
      throw new Error("Only the recipient can accept this message request.");
    }

    await window.supabaseClient
      .from("conversations")
      .update({
        status: "active",
        updated_at: new Date().toISOString()
      })
      .eq("id", conversationId);

    return true;
  },

  /**
   * Recipient declines a pending message request
   */
  async declineRequest(conversationId, currentUserId) {
    const { data: conv } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .eq("id", conversationId)
      .single();

    if (!conv) throw new Error("Conversation not found.");
    if (conv.request_recipient_id !== currentUserId) {
      throw new Error("Only the recipient can decline this message request.");
    }

    await window.supabaseClient
      .from("conversations")
      .update({
        status: "declined",
        updated_at: new Date().toISOString()
      })
      .eq("id", conversationId);

    return true;
  },

  /**
   * Sends a message with reply referencing and 3-message limit validation
   */
  async sendMessage({ conversationId, senderId, content, replyTo = null }) {
    if (!content || !content.trim()) {
      throw new Error("Message content cannot be empty.");
    }

    const cleanContent = content.trim();

    // 1. Verify conversation
    const { data: conv } = await window.supabaseClient
      .from("conversations")
      .select("*")
      .eq("id", conversationId)
      .single();

    if (!conv) throw new Error("Conversation not found.");

    const recipientId = conv.participant_one === senderId ? conv.participant_two : conv.participant_one;

    // 2. Check blocks (both directions)
    const { data: isBlockedByRecipient } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", recipientId)
      .eq("blocked_id", senderId)
      .single();

    if (isBlockedByRecipient) {
      throw new Error("You cannot message this user. They have blocked you.");
    }

    const { data: isBlockedByMe } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", senderId)
      .eq("blocked_id", recipientId)
      .single();

    if (isBlockedByMe) {
      throw new Error("You have blocked this contact. Unblock them first to send messages.");
    }

    // 3. Enforce the 3-message limit for unknown users (Section 11 & 12)
    if (conv.status === "declined") {
      throw new Error("This message request was declined. You cannot send more messages.");
    }

    if (conv.status === "pending_request") {
      if (conv.request_initiator_id === senderId) {
        const limit = window.CONFIG.RULES.UNKNOWN_USER_MESSAGE_LIMIT;
        const currentCount = conv.unknown_message_count || 0;

        if (currentCount >= limit) {
          throw new Error("Message limit reached (3/3). Waiting for recipient to approve the conversation.");
        }

        // Increment count
        await window.supabaseClient
          .from("conversations")
          .update({
            unknown_message_count: currentCount + 1,
            last_message_content: cleanContent,
            last_message_sender_id: senderId,
            last_message_timestamp: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .eq("id", conversationId);
      } else if (conv.request_recipient_id === senderId) {
        // If recipient replies, automatically approve the conversation!
        await window.supabaseClient
          .from("conversations")
          .update({
            status: "active",
            last_message_content: cleanContent,
            last_message_sender_id: senderId,
            last_message_timestamp: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .eq("id", conversationId);
      }
    } else {
      // Active conversation: update last message
      await window.supabaseClient
        .from("conversations")
        .update({
          last_message_content: cleanContent,
          last_message_sender_id: senderId,
          last_message_timestamp: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq("id", conversationId);
    }

    // 4. Insert message record
    const nowIso = new Date().toISOString();
    const newMsg = {
      conversation_id: conversationId,
      sender_id: senderId,
      content: cleanContent,
      reply_to_message_id: replyTo ? replyTo.message_id : null,
      reply_to_sender_name: replyTo ? replyTo.sender_name : null,
      reply_to_snippet: replyTo ? (replyTo.snippet.length > 50 ? replyTo.snippet.substring(0, 50) + "..." : replyTo.snippet) : null,
      status: "sent",
      created_at: nowIso,
      read_at: null
    };

    const { data: inserted, error } = await window.supabaseClient
      .from("messages")
      .insert(newMsg);

    if (error) {
      throw new Error(error.message || "Failed to send message.");
    }

    return inserted;
  },

  /**
   * Retrieves all messages for a conversation and marks partner messages as read
   */
  async getMessages(conversationId, currentUserId) {
    const { data: messages, error } = await window.supabaseClient
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });

    if (error || !messages) return [];

    // Mark partner's unread messages as read
    const unread = messages.filter(m => m.sender_id !== currentUserId && m.status !== "read");
    if (unread.length > 0) {
      const nowIso = new Date().toISOString();
      for (const m of unread) {
        await window.supabaseClient
          .from("messages")
          .update({ status: "read", read_at: nowIso })
          .eq("id", m.id);
        m.status = "read";
        m.read_at = nowIso;
      }
    }

    return messages.map(m => ({
      _id: m.id,
      conversation_id: m.conversation_id,
      sender_id: m.sender_id,
      content: m.content,
      reply_to: m.reply_to_message_id ? {
        message_id: m.reply_to_message_id,
        sender_name: m.reply_to_sender_name,
        snippet: m.reply_to_snippet
      } : null,
      status: m.status,
      created_at: m.created_at,
      read_at: m.read_at
    }));
  },

  /**
   * Checks bidirectional block status between two users
   */
  async checkBlockStatus(currentUserId, targetUserId) {
    if (!currentUserId || !targetUserId) {
      return {
        isBlockedByMe: false,
        isBlockedByPartner: false,
        isBlocked: false,
        is_blocked_by_me: false,
        is_blocked_by_partner: false,
        is_blocked: false
      };
    }

    const { data: blockedByMe } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", currentUserId)
      .eq("blocked_id", targetUserId)
      .single();

    const { data: blockedByPartner } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", targetUserId)
      .eq("blocked_id", currentUserId)
      .single();

    const isByMe = !!blockedByMe;
    const isByPartner = !!blockedByPartner;
    const isAny = isByMe || isByPartner;

    return {
      isBlockedByMe: isByMe,
      isBlockedByPartner: isByPartner,
      isBlocked: isAny,
      is_blocked_by_me: isByMe,
      is_blocked_by_partner: isByPartner,
      is_blocked: isAny
    };
  },

  formatConversation(conv) {
    return {
      _id: conv.id,
      participant_one: conv.participant_one,
      participant_two: conv.participant_two,
      status: conv.status,
      request_initiator_id: conv.request_initiator_id,
      request_recipient_id: conv.request_recipient_id,
      unknown_message_count: conv.unknown_message_count,
      last_message: conv.last_message_content ? {
        content: conv.last_message_content,
        sender_id: conv.last_message_sender_id,
        timestamp: conv.last_message_timestamp
      } : null,
      created_at: conv.created_at,
      updated_at: conv.updated_at
    };
  }
};

window.ChatService = ChatService;
