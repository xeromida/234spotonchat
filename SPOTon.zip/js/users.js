/**
 * SPOTon Chat - User & Profile Service (Supabase Edition)
 * 
 * Manages:
 * - User search (@username) with privacy filters ('who_can_find_me')
 * - Online / Last Seen presence formatting
 * - Profile updates (display name, bio)
 * - Avatar uploads to Supabase Storage bucket ('avatars')
 * - Username change quota (3 changes max) and 3-day cooldown rules
 * - Account blocking via Supabase 'blocks' table
 */

const UserService = {
  /**
   * Search users by username query (e.g. "@alvis" or "alvis")
   */
  async searchUsers(query, currentUserId) {
    if (!query || !query.trim()) return [];

    let cleanQuery = query.trim().toLowerCase();
    if (cleanQuery.startsWith("@")) {
      cleanQuery = cleanQuery.substring(1).trim();
    }
    if (!cleanQuery) return [];

    // Query Supabase profiles table using ILIKE
    const { data: matches, error } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .ilike("username_lower", `%${cleanQuery}%`)
      .limit(20);

    if (error || !matches) {
      console.error("Search error:", error);
      return [];
    }

    // Query blocks
    const { data: myBlocks } = await window.supabaseClient
      .from("blocks")
      .select("blocked_id")
      .eq("blocker_id", currentUserId);

    const { data: blockedByOthers } = await window.supabaseClient
      .from("blocks")
      .select("blocker_id")
      .eq("blocked_id", currentUserId);

    const blockedUserIds = new Set((myBlocks || []).map(b => b.blocked_id));
    const blockedByUserIds = new Set((blockedByOthers || []).map(b => b.blocker_id));

    // Filter results according to privacy settings and blocking
    const results = [];
    for (const user of matches) {
      const isSelf = user.id === currentUserId;

      // Privacy: Check "Who can find me"
      if (!isSelf && user.who_can_find_me === "nobody") {
        continue;
      }

      // Hide if the user blocked current user
      if (!isSelf && blockedByUserIds.has(user.id)) {
        continue;
      }

      if (window.PresenceManager) {
        window.PresenceManager.cacheUserPresence(user.id, user.last_seen);
      }

      const isBlockedByMe = blockedUserIds.has(user.id);

      results.push({
        _id: user.id,
        username: user.username,
        display_name: user.display_name,
        avatar_url: user.avatar_url || "assets/default-avatar.svg",
        bio: user.bio || "",
        current_status: user.current_status || "",
        last_seen: user.last_seen,
        is_online: this.isUserOnline(user.last_seen),
        last_seen_text: this.formatLastSeen(user.last_seen),
        is_self: isSelf,
        is_blocked: isBlockedByMe
      });
    }

    return results;
  },

  /**
   * Check if a user is currently online based on last_seen timestamp
   */
  isUserOnline(lastSeenIso) {
    if (!lastSeenIso) return false;
    const diffSeconds = (Date.now() - new Date(lastSeenIso).getTime()) / 1000;
    return diffSeconds <= window.CONFIG.RULES.ONLINE_THRESHOLD_SECONDS;
  },

  /**
   * Format last seen timestamp into human-friendly text
   */
  formatLastSeen(lastSeenIso) {
    if (!lastSeenIso) return "Offline";
    const diffSeconds = Math.floor((Date.now() - new Date(lastSeenIso).getTime()) / 1000);
    if (diffSeconds < window.CONFIG.RULES.ONLINE_THRESHOLD_SECONDS) {
      return "Online";
    }
    const minutes = Math.floor(diffSeconds / 60);
    if (minutes < 60) return `Last seen ${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `Last seen ${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `Last seen ${days}d ago`;
  },

  /**
   * Update profile display name and bio
   */
  async updateProfile(userId, { displayName, bio }) {
    if (!displayName || !displayName.trim()) {
      throw new Error("Display name cannot be empty.");
    }

    const { data, error } = await window.supabaseClient
      .from("profiles")
      .update({
        display_name: displayName.trim(),
        bio: (bio || "").trim()
      })
      .eq("id", userId);

    if (error) {
      throw new Error(error.message || "Failed to update profile.");
    }

    const { data: updated } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    return updated;
  },

  /**
   * Upload profile picture to Supabase Storage bucket ('avatars')
   */
  async uploadAvatar(userId, file) {
    if (!file) {
      throw new Error("Please select an image file.");
    }

    // 1. Validate file type
    if (!window.CONFIG.RULES.ALLOWED_IMAGE_TYPES.includes(file.type)) {
      throw new Error("Invalid file type. Only JPEG, PNG, WebP, and GIF images are allowed.");
    }

    // 2. Validate file size (max 2MB)
    if (file.size > window.CONFIG.RULES.MAX_AVATAR_SIZE_BYTES) {
      throw new Error("File is too large. Maximum size allowed is 2MB.");
    }

    // 3. Upload to Supabase Storage
    const fileExt = file.name.split('.').pop() || "png";
    const fileName = `${userId}/${Date.now()}.${fileExt}`;

    const { data: uploadData, error: uploadError } = await window.supabaseClient.storage
      .from(window.CONFIG.SUPABASE.STORAGE_BUCKET)
      .upload(fileName, file, {
        cacheControl: "3600",
        upsert: true
      });

    if (uploadError) {
      throw new Error(uploadError.message || "Failed to upload avatar to Supabase Storage.");
    }

    // 4. Retrieve public URL
    const { data: urlData } = window.supabaseClient.storage
      .from(window.CONFIG.SUPABASE.STORAGE_BUCKET)
      .getPublicUrl(uploadData.path || fileName);

    const publicUrl = urlData.publicUrl;

    // 5. Update user's profile record in Supabase
    await window.supabaseClient
      .from("profiles")
      .update({ avatar_url: publicUrl })
      .eq("id", userId);

    return publicUrl;
  },

  /**
   * Change username adhering to 3-change quota and 3-day cooldown rules
   */
  async changeUsername(userId, newUsername) {
    if (!newUsername || !newUsername.trim()) {
      throw new Error("New username cannot be empty.");
    }

    const cleanUsername = newUsername.trim();
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!usernameRegex.test(cleanUsername)) {
      throw new Error("Username must be 3-20 characters long and contain only letters, numbers, and underscores.");
    }

    const { data: user } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    if (!user) throw new Error("User not found.");

    if (user.username.toLowerCase() === cleanUsername.toLowerCase()) {
      throw new Error("New username cannot be the same as your current username.");
    }

    // Check uniqueness
    const normalizedNew = cleanUsername.toLowerCase();
    const { data: existing } = await window.supabaseClient
      .from("profiles")
      .select("id")
      .eq("username_lower", normalizedNew)
      .single();

    if (existing && existing.id !== userId) {
      throw new Error("Username already taken. Please choose another.");
    }

    // Enforce 3-change limit and 3-day cooldown
    const maxChanges = window.CONFIG.RULES.MAX_USERNAME_CHANGES;
    const cooldownDays = window.CONFIG.RULES.USERNAME_CHANGE_COOLDOWN_DAYS;
    const cooldownMs = cooldownDays * 24 * 60 * 60 * 1000;

    let count = user.username_changes_count || 0;

    if (count >= maxChanges) {
      if (!user.last_username_change) {
        throw new Error("Username change limit reached.");
      }

      const elapsedMs = Date.now() - new Date(user.last_username_change).getTime();
      if (elapsedMs < cooldownMs) {
        const remainingDays = Math.ceil((cooldownMs - elapsedMs) / (24 * 60 * 60 * 1000));
        throw new Error(`Username change limit reached (${maxChanges}/${maxChanges}). You can change your username again in ${remainingDays} day${remainingDays > 1 ? 's' : ''}.`);
      } else {
        // Cooldown passed: reset count for next cycle
        count = 0;
      }
    }

    const nowIso = new Date().toISOString();

    // Log history
    await window.supabaseClient
      .from("username_change_history")
      .insert({
        user_id: userId,
        old_username: user.username,
        new_username: cleanUsername,
        changed_at: nowIso
      });

    // Update profile
    await window.supabaseClient
      .from("profiles")
      .update({
        username: cleanUsername,
        username_lower: normalizedNew,
        username_changes_count: count + 1,
        last_username_change: nowIso
      })
      .eq("id", userId);

    const { data: updated } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    return updated;
  },

  /**
   * Get quota and cooldown status for username changes
   */
  getUsernameChangeStatus(user) {
    const maxChanges = window.CONFIG.RULES.MAX_USERNAME_CHANGES;
    const cooldownDays = window.CONFIG.RULES.USERNAME_CHANGE_COOLDOWN_DAYS;
    const cooldownMs = cooldownDays * 24 * 60 * 60 * 1000;

    const count = user.username_changes_count || 0;

    if (count >= maxChanges) {
      if (user.last_username_change) {
        const elapsedMs = Date.now() - new Date(user.last_username_change).getTime();
        if (elapsedMs < cooldownMs) {
          const remainingDays = Math.ceil((cooldownMs - elapsedMs) / (24 * 60 * 60 * 1000));
          return {
            canChange: false,
            remainingChanges: 0,
            message: `You can change your username again in ${remainingDays} day${remainingDays > 1 ? 's' : ''}.`
          };
        }
      }
      return {
        canChange: true,
        remainingChanges: maxChanges,
        message: `Cooldown complete. You have ${maxChanges} changes remaining.`
      };
    }

    const remaining = maxChanges - count;
    return {
      canChange: true,
      remainingChanges: remaining,
      message: `Username changes remaining: ${remaining}`
    };
  },

  /**
   * Block a user
   */
  async blockUser(blockerId, blockedId) {
    if (blockerId === blockedId) {
      throw new Error("You cannot block yourself.");
    }

    const { data: existing } = await window.supabaseClient
      .from("blocks")
      .select("id")
      .eq("blocker_id", blockerId)
      .eq("blocked_id", blockedId)
      .single();

    if (!existing) {
      await window.supabaseClient
        .from("blocks")
        .insert({
          blocker_id: blockerId,
          blocked_id: blockedId,
          created_at: new Date().toISOString()
        });
    }

    return true;
  },

  /**
   * Unblock a user
   */
  async unblockUser(blockerId, blockedId) {
    await window.supabaseClient
      .from("blocks")
      .delete()
      .eq("blocker_id", blockerId)
      .eq("blocked_id", blockedId);

    return true;
  },

  /**
   * Get all blocked accounts for a user
   */
  async getBlockedUsers(userId) {
    const { data: blocks } = await window.supabaseClient
      .from("blocks")
      .select("blocked_id")
      .eq("blocker_id", userId);

    if (!blocks || blocks.length === 0) return [];

    const blockedIds = blocks.map(b => b.blocked_id);
    const { data: profiles } = await window.supabaseClient
      .from("profiles")
      .select("id, username, display_name, avatar_url")
      .in("id", blockedIds);

    return (profiles || []).map(u => ({
      _id: u.id,
      username: u.username,
      display_name: u.display_name,
      avatar_url: u.avatar_url || "assets/default-avatar.svg"
    }));
  }
};

window.UserService = UserService;
