/**
 * SPOTon Chat - Authentication Service (Supabase Edition)
 * 
 * Manages:
 * - Mathematical CAPTCHA challenge generation & validation
 * - User registration via Supabase Auth + profiles table
 * - User login & credential verification via Supabase Auth
 * - Session state management & logout
 */

const AuthService = {
  currentCaptchaAnswer: null,

  /**
   * Generates a dynamic math CAPTCHA challenge
   * Format: "7 + 4 = ?"
   */
  generateCaptcha() {
    const num1 = Math.floor(Math.random() * 12) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    this.currentCaptchaAnswer = num1 + num2;
    return `${num1} + ${num2} = ?`;
  },

  /**
   * Verifies the user's submitted CAPTCHA answer
   */
  verifyCaptcha(userAnswer) {
    if (this.currentCaptchaAnswer === null) return false;
    const parsed = parseInt(String(userAnswer).trim(), 10);
    return !isNaN(parsed) && parsed === this.currentCaptchaAnswer;
  },

  /**
   * Registers a new user using Supabase Auth and creates a profile record
   */
  async register({ username, password, confirmPassword, captchaAnswer, displayName }) {
    // 1. Validate inputs
    if (!username || !username.trim()) {
      throw new Error("Username is required.");
    }
    const cleanUsername = username.trim();
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!usernameRegex.test(cleanUsername)) {
      throw new Error("Username must be 3-20 characters long and contain only letters, numbers, and underscores.");
    }

    if (!password) {
      throw new Error("Password is required.");
    }
    if (password.length < 6) {
      throw new Error("Password must be at least 6 characters long.");
    }
    if (password !== confirmPassword) {
      throw new Error("Passwords do not match.");
    }

    // 2. Validate CAPTCHA
    if (!captchaAnswer || !this.verifyCaptcha(captchaAnswer)) {
      throw new Error("Incorrect CAPTCHA answer. Please solve the equation.");
    }

    const normalizedUsername = cleanUsername.toLowerCase();

    // 3. Check username uniqueness in Supabase profiles table
    const { data: existingProfile } = await window.supabaseClient
      .from("profiles")
      .select("id")
      .eq("username_lower", normalizedUsername)
      .single();

    if (existingProfile) {
      throw new Error("Username already exists. Please choose another.");
    }

    // 4. Register with Supabase Auth
    // Use standard .com domain format so Supabase Auth email validator accepts it
    const authEmail = `${normalizedUsername}@spotonchat.com`;
    const finalDisplayName = displayName && displayName.trim() ? displayName.trim() : cleanUsername;

    const { data: authData, error: authError } = await window.supabaseClient.auth.signUp({
      email: authEmail,
      password: password,
      options: {
        data: {
          username: cleanUsername,
          display_name: finalDisplayName
        }
      }
    });

    if (authError) {
      if (authError.message.toLowerCase().includes("rate limit")) {
        throw new Error("Supabase email rate limit reached (2 emails/hr). Fix: In your Supabase Dashboard, go to Authentication > Providers > Email, turn OFF 'Confirm email', and click Save.");
      }
      throw new Error(authError.message || "Failed to create account with Supabase Auth.");
    }

    const user = authData.user;
    if (!user) {
      throw new Error("Registration failed. No user was returned.");
    }

    // 5. Ensure profile is created in public.profiles table
    const nowIso = new Date().toISOString();
    const profilePayload = {
      id: user.id,
      username: cleanUsername,
      username_lower: normalizedUsername,
      display_name: finalDisplayName,
      avatar_url: "",
      bio: "Hey there! I am using SPOTon Chat.",
      current_status: "Available",
      status_updated_at: nowIso,
      who_can_find_me: "everyone",
      allow_message_requests: true,
      username_changes_count: 0,
      last_username_change: null,
      last_seen: nowIso,
      created_at: nowIso
    };

    // If Supabase didn't return an active session on signup, sign in automatically
    if (!authData.session) {
      try {
        await window.supabaseClient.auth.signInWithPassword({
          email: authEmail,
          password: password
        });
      } catch (e) {
        console.warn("Auto-login note:", e);
      }
    }

    // Try to insert profile if trigger hasn't already created it
    try {
      await window.supabaseClient
        .from("profiles")
        .insert(profilePayload);
    } catch (profileError) {
      console.warn("Profile creation note:", profileError);
    }

    // Retrieve active profile
    let { data: profile } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    if (!profile) {
      profile = profilePayload;
    }

    profile._id = profile.id;
    localStorage.setItem(window.CONFIG.CURRENT_USER_KEY, JSON.stringify(profile));
    return profile;
  },

  /**
   * Logs a user in with username and password via Supabase Auth
   */
  async login(username, password) {
    if (!username || !password) {
      throw new Error("Please enter both username and password.");
    }

    const normalizedUsername = username.trim().toLowerCase();
    const authEmail = `${normalizedUsername}@spotonchat.com`;

    // Sign in via Supabase Auth
    const { data: authData, error: authError } = await window.supabaseClient.auth.signInWithPassword({
      email: authEmail,
      password: password
    });

    if (authError) {
      throw new Error(authError.message || "User not found or incorrect password.");
    }

    // Retrieve profile from Supabase profiles table
    const { data: profile, error: profileErr } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", authData.user.id)
      .single();

    if (profileErr || !profile) {
      throw new Error("Could not load user profile from database.");
    }

    // Update last_seen timestamp
    const nowIso = new Date().toISOString();
    await window.supabaseClient
      .from("profiles")
      .update({ last_seen: nowIso })
      .eq("id", profile.id);

    profile.last_seen = nowIso;
    profile._id = profile.id;
    localStorage.setItem(window.CONFIG.CURRENT_USER_KEY, JSON.stringify(profile));
    return profile;
  },

  /**
   * Retrieves the currently authenticated user from Supabase session
   */
  async getCurrentUser() {
    const { data: sessionData } = await window.supabaseClient.auth.getSession();
    if (!sessionData || !sessionData.session) {
      return null;
    }

    const userId = sessionData.session.user.id;
    const { data: profile } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    if (!profile) {
      await this.logout();
      return null;
    }

    // Update presence heartbeat
    const nowIso = new Date().toISOString();
    await window.supabaseClient
      .from("profiles")
      .update({ last_seen: nowIso })
      .eq("id", profile.id);

    profile.last_seen = nowIso;
    profile._id = profile.id;
    localStorage.setItem(window.CONFIG.CURRENT_USER_KEY, JSON.stringify(profile));
    return profile;
  },

  /**
   * Logs out the user from Supabase Auth
   */
  async logout() {
    await window.supabaseClient.auth.signOut();
    localStorage.removeItem(window.CONFIG.SESSION_STORAGE_KEY);
    localStorage.removeItem(window.CONFIG.CURRENT_USER_KEY);
  },

  sanitizeUser(user) {
    if (!user) return null;
    const copy = { ...user };
    delete copy.password;
    delete copy.password_hash;
    return copy;
  }
};

window.AuthService = AuthService;
