/**
 * SPOTon Chat - Realtime Presence & Activity Tracking Manager
 * 
 * Manages:
 * - Supabase Realtime Presence channel (join, leave, sync)
 * - Lightweight activity heartbeat with idle/tab visibility detection
 * - Client-side automatic relative last-seen updates (zero database queries)
 * - Realtime UI synchronization across all visible presence indicators
 */

const PresenceManager = {
  currentUserId: null,
  presenceChannel: null,
  heartbeatTimer: null,
  relativeTimer: null,
  lastActivityTime: Date.now(),
  isUserActive: true,

  // In-memory cache of user presence: userId -> { isOnline: boolean, lastSeenIso: string }
  presenceCache: new Map(),

  /**
   * Initializes presence tracking for the logged-in user
   */
  init(userId) {
    this.currentUserId = userId;
    this.presenceCache.clear();
    this.lastActivityTime = Date.now();
    this.isUserActive = true;

    this.bindActivityEvents();
    this.initRealtimePresence();
    this.startHeartbeat();
    this.startRelativeTimeTicker();
  },

  /**
   * Shuts down presence tracking on logout
   */
  destroy() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.relativeTimer) clearInterval(this.relativeTimer);
    if (this.presenceChannel && this.presenceChannel.unsubscribe) {
      try {
        this.presenceChannel.unsubscribe();
      } catch (e) {
        console.warn("Presence unsubscribe error:", e);
      }
    }
    this.presenceChannel = null;
    this.presenceCache.clear();
    this.currentUserId = null;
  },

  /**
   * Connects to Supabase Realtime presence channel
   */
  initRealtimePresence() {
    if (!window.supabaseClient || !this.currentUserId) return;

    try {
      this.presenceChannel = window.supabaseClient.channel("spoton-presence", {
        config: { presence: { key: this.currentUserId } }
      });

      this.presenceChannel
        .on("presence", { event: "sync" }, () => {
          this.handlePresenceSync();
        })
        .on("presence", { event: "join" }, ({ key, newPresences }) => {
          this.setUserOnline(key, true, new Date().toISOString());
        })
        .on("presence", { event: "leave" }, ({ key, leftPresences }) => {
          const nowIso = new Date().toISOString();
          this.setUserOnline(key, false, nowIso);
        })
        .subscribe(async (status) => {
          if (status === "SUBSCRIBED") {
            await this.trackPresence(true);
          }
        });

      // Also listen to database profile changes for last_seen updates
      window.supabaseClient
        .channel("public-profiles-presence")
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "profiles" },
          (payload) => {
            if (payload && payload.new) {
              const updated = payload.new;
              const cached = this.presenceCache.get(updated.id);
              const isOnline = cached ? cached.isOnline : UserService.isUserOnline(updated.last_seen);
              this.presenceCache.set(updated.id, {
                isOnline,
                lastSeenIso: updated.last_seen
              });
              this.syncDOMPresence(updated.id);
            }
          }
        )
        .subscribe();
    } catch (e) {
      console.warn("Could not start Realtime presence channel:", e);
    }
  },

  /**
   * Tracks own presence on the Realtime channel
   */
  async trackPresence(isOnline = true) {
    if (!this.presenceChannel || !this.presenceChannel.track || !this.currentUserId) return;
    try {
      if (isOnline) {
        await this.presenceChannel.track({
          user_id: this.currentUserId,
          online_at: new Date().toISOString()
        });
      } else if (this.presenceChannel.untrack) {
        await this.presenceChannel.untrack();
      }
    } catch (e) {
      console.warn("Track presence note:", e);
    }
  },

  /**
   * Handles presence sync from Supabase Realtime
   */
  handlePresenceSync() {
    if (!this.presenceChannel || !this.presenceChannel.presenceState) return;
    try {
      const state = this.presenceChannel.presenceState();
      const onlineKeys = new Set(Object.keys(state));

      // Mark all synced users online
      for (const userId of onlineKeys) {
        this.setUserOnline(userId, true, new Date().toISOString());
      }
    } catch (e) {
      console.warn("Presence sync note:", e);
    }
  },

  /**
   * Updates in-memory presence for a user and triggers DOM sync
   */
  setUserOnline(userId, isOnline, lastSeenIso) {
    if (!userId) return;
    const existing = this.presenceCache.get(userId) || {};
    this.presenceCache.set(userId, {
      isOnline: isOnline,
      lastSeenIso: lastSeenIso || existing.lastSeenIso || new Date().toISOString()
    });
    this.syncDOMPresence(userId);
  },

  /**
   * Seeds cached presence for a user from profile/database load
   */
  cacheUserPresence(userId, lastSeenIso) {
    if (!userId) return;
    const existing = this.presenceCache.get(userId);
    if (!existing) {
      this.presenceCache.set(userId, {
        isOnline: UserService.isUserOnline(lastSeenIso),
        lastSeenIso: lastSeenIso || new Date().toISOString()
      });
    } else if (lastSeenIso) {
      existing.lastSeenIso = lastSeenIso;
    }
  },

  /**
   * Retrieves presence status for a user
   */
  getUserPresence(userId, fallbackLastSeen = null) {
    const cached = this.presenceCache.get(userId);
    if (cached) {
      const isOnline = cached.isOnline && this.isTimestampRecent(cached.lastSeenIso);
      return {
        isOnline,
        lastSeenIso: cached.lastSeenIso,
        statusText: isOnline ? "🟢 Online" : UserService.formatLastSeen(cached.lastSeenIso)
      };
    }

    const isOnline = UserService.isUserOnline(fallbackLastSeen);
    return {
      isOnline,
      lastSeenIso: fallbackLastSeen,
      statusText: isOnline ? "🟢 Online" : UserService.formatLastSeen(fallbackLastSeen)
    };
  },

  isTimestampRecent(lastSeenIso) {
    if (!lastSeenIso) return false;
    const diffSeconds = (Date.now() - new Date(lastSeenIso).getTime()) / 1000;
    return diffSeconds <= window.CONFIG.RULES.ONLINE_THRESHOLD_SECONDS;
  },

  /**
   * Activity tracking events (heartbeat throttling)
   */
  bindActivityEvents() {
    const onActivity = () => {
      this.lastActivityTime = Date.now();
      if (!this.isUserActive) {
        this.isUserActive = true;
        this.trackPresence(true);
      }
    };

    window.addEventListener("mousemove", onActivity, { passive: true });
    window.addEventListener("keydown", onActivity, { passive: true });
    window.addEventListener("touchstart", onActivity, { passive: true });
    window.addEventListener("focus", onActivity);

    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        this.isUserActive = false;
        this.trackPresence(false);
      } else {
        this.isUserActive = true;
        this.lastActivityTime = Date.now();
        this.trackPresence(true);
      }
    });
  },

  /**
   * Lightweight periodic heartbeat (every 30 seconds)
   */
  startHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);

    this.heartbeatTimer = setInterval(async () => {
      if (!this.currentUserId || document.hidden) return;

      // Check if user was active in the last 2 minutes
      const idleTimeMs = Date.now() - this.lastActivityTime;
      if (idleTimeMs > 2 * 60 * 1000) {
        this.isUserActive = false;
        return;
      }

      const nowIso = new Date().toISOString();
      try {
        await window.supabaseClient
          .from("profiles")
          .update({ last_seen: nowIso })
          .eq("id", this.currentUserId);

        this.setUserOnline(this.currentUserId, true, nowIso);
      } catch (e) {
        console.warn("Heartbeat error:", e);
      }
    }, window.CONFIG.RULES.HEARTBEAT_INTERVAL_MS || 30000);
  },

  /**
   * High-efficiency client-side timer (every 10s)
   * Automatically updates relative last-seen text (e.g. "1m ago" -> "2m ago")
   * without ANY database requests!
   */
  startRelativeTimeTicker() {
    if (this.relativeTimer) clearInterval(this.relativeTimer);

    this.relativeTimer = setInterval(() => {
      this.updateAllRelativeTimes();
    }, 10000); // Ticks every 10 seconds
  },

  /**
   * Iterates through all presence DOM elements and refreshes text locally
   */
  updateAllRelativeTimes() {
    // 1. Update all presence text nodes
    const presenceEls = document.querySelectorAll("[data-presence-user-id]");
    presenceEls.forEach(el => {
      const userId = el.getAttribute("data-presence-user-id");
      const lastSeenAttr = el.getAttribute("data-last-seen-iso");
      const presence = this.getUserPresence(userId, lastSeenAttr);

      el.textContent = presence.statusText;
      if (presence.isOnline) {
        el.classList.add("text-online");
      } else {
        el.classList.remove("text-online");
      }
    });

    // 2. Update all presence indicator dots
    const dotEls = document.querySelectorAll("[data-presence-dot-user-id]");
    dotEls.forEach(dot => {
      const userId = dot.getAttribute("data-presence-dot-user-id");
      const lastSeenAttr = dot.getAttribute("data-last-seen-iso");
      const presence = this.getUserPresence(userId, lastSeenAttr);

      if (presence.isOnline) {
        dot.classList.remove("offline");
        dot.classList.add("online");
      } else {
        dot.classList.remove("online");
        dot.classList.add("offline");
      }
    });
  },

  /**
   * Synchronizes currently visible UI elements for a specific user ID
   */
  syncDOMPresence(userId) {
    if (!userId) return;
    const presence = this.getUserPresence(userId);

    // Update text elements matching this user
    document.querySelectorAll(`[data-presence-user-id="${userId}"]`).forEach(el => {
      el.textContent = presence.statusText;
      if (presence.isOnline) {
        el.classList.add("text-online");
      } else {
        el.classList.remove("text-online");
      }
    });

    // Update dot elements matching this user
    document.querySelectorAll(`[data-presence-dot-user-id="${userId}"]`).forEach(dot => {
      if (presence.isOnline) {
        dot.classList.remove("offline");
        dot.classList.add("online");
      } else {
        dot.classList.remove("online");
        dot.classList.add("offline");
      }
    });
  }
};

window.PresenceManager = PresenceManager;
