/**
 * SPOTon Chat - Main Application Controller & UI Binder
 * 
 * Ties all components together cleanly:
 * - Landing page & Auth modals
 * - Chat stream, replies, read receipts, and 3-message limit
 * - BBM-style status feed
 * - User search (@username) & privacy checks
 * - Username change restrictions & avatar uploads
 */

const App = {
  currentUser: null,
  activeConversation: null,
  activePartner: null,
  activeReplyTo: null,
  pollingInterval: null,
  heartbeatInterval: null,

  async init() {
    this.bindEvents();

    // Check existing session
    try {
      this.currentUser = await AuthService.getCurrentUser();
      if (this.currentUser) {
        this.showMainApp();
      } else {
        this.showLandingPage();
      }
    } catch (e) {
      console.error("Session initialization error:", e);
      this.showLandingPage();
    }
  },

  // =========================================================================
  // VIEW SWITCHING (Landing Page vs Main Chat App)
  // =========================================================================

  showLandingPage() {
    document.getElementById("landing-view").classList.remove("hidden");
    document.getElementById("main-app-view").classList.add("hidden");
    this.stopPolling();
  },

  async showMainApp() {
    document.getElementById("landing-view").classList.add("hidden");
    document.getElementById("main-app-view").classList.remove("hidden");

    this.renderSidebarUser();

    // Initialize Realtime Presence Tracking (Update 9)
    if (window.PresenceManager) {
      PresenceManager.init(this.currentUser._id || this.currentUser.id);
    }

    await this.loadConversations();
    await this.checkMessageRequests();
    await this.loadStatusFeed();
    this.loadSettings();

    // Initialize Supabase Realtime channel for instant messaging
    ChatService.initRealtime(() => {
      this.loadConversations(true);
      if (this.activeConversation) {
        this.loadMessages(this.activeConversation._id, true);
      }
    });

    this.startPolling();
  },

  renderSidebarUser() {
    if (!this.currentUser) return;
    const nameEl = document.getElementById("sidebar-my-name");
    const handleEl = document.getElementById("sidebar-my-handle");
    const avatarEl = document.getElementById("sidebar-my-avatar");

    nameEl.textContent = this.currentUser.display_name || this.currentUser.username;
    handleEl.textContent = `@${this.currentUser.username}`;
    avatarEl.src = this.currentUser.avatar_url || "assets/default-avatar.svg";
  },

  // =========================================================================
  // POLLING & HEARTBEAT ENGINE
  // =========================================================================

  startPolling() {
    this.stopPolling();

    // Periodic message & presence poll (every 3 seconds as backup to Realtime)
    this.pollingInterval = setInterval(async () => {
      if (!this.currentUser) return;
      await this.loadConversations(true);
      await this.checkMessageRequests(true);
      if (this.activeConversation) {
        await this.loadMessages(this.activeConversation._id, true);
      }
    }, window.CONFIG.RULES.POLL_INTERVAL_MS);

    // Periodic presence heartbeat (every 30 seconds)
    this.heartbeatInterval = setInterval(async () => {
      if (!this.currentUser) return;
      await window.supabaseClient
        .from("profiles")
        .update({ last_seen: new Date().toISOString() })
        .eq("id", this.currentUser._id || this.currentUser.id);
    }, window.CONFIG.RULES.HEARTBEAT_INTERVAL_MS);
  },

  stopPolling() {
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
  },

  // =========================================================================
  // CONVERSATIONS & CHAT ENGINE
  // =========================================================================

  async loadConversations(isBackground = false) {
    try {
      const convs = await ChatService.getUserConversations(this.currentUser._id);
      const listEl = document.getElementById("conversations-list");
      const emptyEl = document.getElementById("conversations-empty");
      const totalUnreadBadge = document.getElementById("badge-total-unread");

      let totalUnread = 0;

      if (!isBackground) {
        listEl.innerHTML = "";
      }

      if (convs.length === 0) {
        listEl.innerHTML = "";
        emptyEl.classList.remove("hidden");
        totalUnreadBadge.classList.add("hidden");
        return;
      }

      emptyEl.classList.add("hidden");

      let html = "";
      for (const conv of convs) {
        totalUnread += conv.unread_count || 0;
        const isActive = this.activeConversation && this.activeConversation._id === conv._id;
        const partner = conv.partner;
        const timeStr = conv.last_message ? StatusService.formatTimeAgo(conv.last_message.timestamp) : "";

        // Cache presence and determine current status
        if (window.PresenceManager) {
          PresenceManager.cacheUserPresence(partner._id, partner.last_seen);
        }
        const presence = window.PresenceManager
          ? PresenceManager.getUserPresence(partner._id, partner.last_seen)
          : { isOnline: partner.is_online };
        const onlineClass = presence.isOnline ? "online" : "offline";

        // Check if blocked in either direction (Update 3 & 5)
        let snippetHtml = "";
        if (conv.is_blocked_by_me) {
          snippetHtml = `<span class="conv-snippet blocked truncate">⚠️ You blocked this contact</span>`;
        } else if (conv.is_blocked_by_partner) {
          snippetHtml = `<span class="conv-snippet blocked truncate">⚠️ Contact blocked you</span>`;
        } else {
          const lastMsg = conv.last_message ? conv.last_message.content : "No messages yet";
          snippetHtml = `<span class="conv-snippet truncate">${CryptoUtils.escapeHTML(lastMsg)}</span>`;
        }

        html += `
          <div class="conv-item ${isActive ? 'active' : ''}" data-conv-id="${conv._id}" data-partner-id="${partner._id}">
            <div class="avatar-wrap">
              <img class="avatar" src="${partner.avatar_url}" alt="${CryptoUtils.escapeHTML(partner.display_name)}">
              <div class="online-dot ${onlineClass}" data-presence-dot-user-id="${partner._id}" data-last-seen-iso="${partner.last_seen || ''}"></div>
            </div>
            <div class="conv-content truncate">
              <div class="conv-header-row">
                <span class="conv-name truncate">${CryptoUtils.escapeHTML(partner.display_name)}</span>
                <span class="conv-time">${timeStr}</span>
              </div>
              <div class="conv-snippet-row">
                ${snippetHtml}
                ${conv.unread_count > 0 ? `<span class="badge badge-primary">${conv.unread_count}</span>` : ''}
              </div>
            </div>
          </div>
        `;
      }

      listEl.innerHTML = html;

      // Update unread count badge on the tab
      if (totalUnread > 0) {
        totalUnreadBadge.textContent = totalUnread;
        totalUnreadBadge.classList.remove("hidden");
      } else {
        totalUnreadBadge.classList.add("hidden");
      }
    } catch (e) {
      console.error("Error loading conversations:", e);
    }
  },

  async selectConversation(convId) {
    try {
      const { data: conv } = await window.supabaseClient
        .from("conversations")
        .select("*")
        .eq("id", convId)
        .single();
      if (!conv) return;

      const formattedConv = ChatService.formatConversation(conv);
      this.activeConversation = formattedConv;
      this.cancelReply();

      // Update active highlight in conversation list
      document.querySelectorAll(".conv-item").forEach(el => {
        el.classList.toggle("active", el.getAttribute("data-conv-id") === convId);
      });

      // Show active chat window
      document.getElementById("chat-placeholder").classList.add("hidden");
      document.getElementById("active-chat-window").classList.remove("hidden");

      // Mobile visibility
      document.querySelector(".app-chat-area").classList.add("mobile-visible");

      // Load partner details for header
      const myId = this.currentUser._id || this.currentUser.id;
      const partnerId = conv.participant_one === myId ? conv.participant_two : conv.participant_one;
      const { data: partner } = await window.supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", partnerId)
        .single();

      if (partner) {
        this.activePartner = partner;
        document.getElementById("chat-header-avatar").src = partner.avatar_url || "assets/default-avatar.svg";
        document.getElementById("chat-header-name").textContent = partner.display_name || partner.username;

        if (window.PresenceManager) {
          PresenceManager.cacheUserPresence(partner.id, partner.last_seen);
        }
        const presence = window.PresenceManager
          ? PresenceManager.getUserPresence(partner.id, partner.last_seen)
          : { isOnline: UserService.isUserOnline(partner.last_seen), statusText: UserService.isUserOnline(partner.last_seen) ? "Online" : UserService.formatLastSeen(partner.last_seen) };

        const headerDot = document.getElementById("chat-header-online-dot");
        const headerStatus = document.getElementById("chat-header-status");

        headerDot.className = `online-dot ${presence.isOnline ? 'online' : 'offline'}`;
        headerDot.setAttribute("data-presence-dot-user-id", partner.id);
        headerDot.setAttribute("data-last-seen-iso", partner.last_seen || "");

        headerStatus.textContent = presence.statusText;
        headerStatus.setAttribute("data-presence-user-id", partner.id);
        headerStatus.setAttribute("data-last-seen-iso", partner.last_seen || "");
        if (presence.isOnline) {
          headerStatus.classList.add("text-online");
        } else {
          headerStatus.classList.remove("text-online");
        }

        // Check Block status (Update 3 & 4)
        const blockStatus = await ChatService.checkBlockStatus(myId, partner.id);
        this.updateBlockStateUI(blockStatus, partner);
      }

      // Check Pending Message Request state (Section 11 & 12)
      this.updateRequestBanner(formattedConv);

      // Load messages
      await this.loadMessages(convId);

      // Focus message input
      if (!document.getElementById("message-input").disabled) {
        document.getElementById("message-input").focus();
      }
    } catch (e) {
      console.error("Error selecting conversation:", e);
      this.showToast("Failed to open conversation.", "danger");
    }
  },

  updateBlockStateUI(blockStatus, partner) {
    const banner = document.getElementById("chat-blocked-banner");
    const bannerMsg = document.getElementById("chat-blocked-message");
    const bannerUnblockBtn = document.getElementById("btn-unblock-from-banner");
    const messageInput = document.getElementById("message-input");
    const sendBtn = document.getElementById("btn-send-message");
    const menuBlockText = document.getElementById("menu-item-block-text");
    const menuBlockIcon = document.getElementById("menu-item-block-icon");
    const menuToggleBlock = document.getElementById("menu-item-toggle-block");

    const partnerName = partner ? (partner.display_name || partner.username) : "this contact";
    const isBlockedByMe = blockStatus && (blockStatus.is_blocked_by_me || blockStatus.isBlockedByMe);
    const isBlockedByPartner = blockStatus && (blockStatus.is_blocked_by_partner || blockStatus.isBlockedByPartner);

    if (isBlockedByMe) {
      banner.classList.remove("hidden");
      bannerMsg.textContent = "You blocked this contact.";
      bannerUnblockBtn.classList.remove("hidden");

      messageInput.disabled = true;
      messageInput.placeholder = "You blocked this contact. Unblock to message.";
      sendBtn.disabled = true;

      if (menuBlockText) menuBlockText.textContent = "Unblock Contact";
      if (menuBlockIcon) menuBlockIcon.textContent = "✅";
      if (menuToggleBlock) menuToggleBlock.setAttribute("data-action", "unblock");
    } else if (isBlockedByPartner) {
      banner.classList.remove("hidden");
      bannerMsg.textContent = `${partnerName} has blocked you. Messaging is unavailable.`;
      bannerUnblockBtn.classList.add("hidden");

      messageInput.disabled = true;
      messageInput.placeholder = "Messaging unavailable.";
      sendBtn.disabled = true;

      if (menuBlockText) menuBlockText.textContent = "Block Contact";
      if (menuBlockIcon) menuBlockIcon.textContent = "🚫";
      if (menuToggleBlock) menuToggleBlock.setAttribute("data-action", "block");
    } else {
      banner.classList.add("hidden");
      bannerUnblockBtn.classList.add("hidden");

      messageInput.disabled = false;
      messageInput.placeholder = "Type a message...";
      sendBtn.disabled = false;

      if (menuBlockText) menuBlockText.textContent = "Block Contact";
      if (menuBlockIcon) menuBlockIcon.textContent = "🚫";
      if (menuToggleBlock) menuToggleBlock.setAttribute("data-action", "block");
    }
  },

  openBlockConfirmModal(partner) {
    if (!partner) return;
    const name = partner.display_name || partner.username;
    const msgEl = document.getElementById("block-confirm-message");
    if (msgEl) {
      msgEl.textContent = `Are you sure you want to block ${name}? They will not be able to send you messages, and you won't be able to message them.`;
    }
    this.openModal("block-confirm-modal");
  },

  openUnblockConfirmModal(partner) {
    if (!partner) return;
    const name = partner.display_name || partner.username;
    const msgEl = document.getElementById("unblock-confirm-message");
    if (msgEl) {
      msgEl.textContent = `Unblock ${name}? They will be able to send you messages and view your status updates again.`;
    }
    this.openModal("unblock-confirm-modal");
  },

  updateRequestBanner(conv) {
    const banner = document.getElementById("chat-request-banner");
    const msgEl = document.getElementById("chat-request-message");
    const actionsEl = banner.querySelector(".request-actions");

    if (conv.status === "pending_request") {
      banner.classList.remove("hidden");
      if (conv.request_recipient_id === this.currentUser._id) {
        // Current user is recipient: show Accept/Decline
        msgEl.textContent = "This user sent you a message request.";
        actionsEl.classList.remove("hidden");
      } else {
        // Current user is sender: show 3-message limit count
        const count = conv.unknown_message_count || 0;
        const max = window.CONFIG.RULES.UNKNOWN_USER_MESSAGE_LIMIT;
        msgEl.textContent = `Pending approval. Message limit: ${count}/${max} sent.`;
        actionsEl.classList.add("hidden");
      }
    } else {
      banner.classList.add("hidden");
    }
  },

  async loadMessages(convId, isBackground = false) {
    try {
      const messages = await ChatService.getMessages(convId, this.currentUser._id);
      const container = document.getElementById("chat-messages-container");

      const isScrolledToBottom = container.scrollHeight - container.clientHeight <= container.scrollTop + 60;

      let html = "";
      for (const msg of messages) {
        const isOutgoing = msg.sender_id === this.currentUser._id;
        const timeStr = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Read Status Tick (Section 15)
        let tickHtml = "";
        if (isOutgoing) {
          if (msg.status === "read") {
            tickHtml = `<span class="read-tick read" title="Read">✓✓</span>`;
          } else if (msg.status === "delivered") {
            tickHtml = `<span class="read-tick delivered" title="Delivered">✓✓</span>`;
          } else {
            tickHtml = `<span class="read-tick" title="Sent">✓</span>`;
          }
        }

        // Reply quote snippet (Section 14)
        let replyHtml = "";
        if (msg.reply_to) {
          replyHtml = `
            <div class="reply-quote-box">
              <div class="reply-quote-sender">${CryptoUtils.escapeHTML(msg.reply_to.sender_name)}</div>
              <div class="reply-quote-text">${CryptoUtils.escapeHTML(msg.reply_to.snippet)}</div>
            </div>
          `;
        }

        html += `
          <div class="message-row ${isOutgoing ? 'outgoing' : 'incoming'}" data-msg-id="${msg._id}">
            <div class="message-bubble">
              ${replyHtml}
              <div class="message-text">${CryptoUtils.escapeHTML(msg.content)}</div>
            </div>
            <div class="message-meta">
              <span>${timeStr}</span>
              ${tickHtml}
            </div>
            <div class="message-actions">
              <button class="action-icon-btn btn-reply-msg" data-msg-id="${msg._id}" data-sender-name="${isOutgoing ? 'You' : 'Partner'}" data-snippet="${CryptoUtils.escapeHTML(msg.content)}" title="Reply">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="9 17 4 12 9 7"></polyline>
                  <path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>
                </svg>
              </button>
            </div>
          </div>
        `;
      }

      container.innerHTML = html;

      // Scroll down if first load or was already at bottom
      if (!isBackground || isScrolledToBottom) {
        container.scrollTop = container.scrollHeight;
      }
    } catch (e) {
      console.error("Error loading messages:", e);
    }
  },

  async handleSendMessage() {
    const input = document.getElementById("message-input");
    const content = input.value.trim();
    if (!content || !this.activeConversation) return;

    try {
      await ChatService.sendMessage({
        conversationId: this.activeConversation._id,
        senderId: this.currentUser._id,
        content: content,
        replyTo: this.activeReplyTo
      });

      input.value = "";
      this.cancelReply();

      // Refresh conversation state and messages
      const { data: updatedConv } = await window.supabaseClient
        .from("conversations")
        .select("*")
        .eq("id", this.activeConversation._id)
        .single();

      if (updatedConv) {
        const formatted = ChatService.formatConversation(updatedConv);
        this.activeConversation = formatted;
        this.updateRequestBanner(formatted);
      }

      await this.loadMessages(this.activeConversation._id);
      await this.loadConversations(true);
    } catch (err) {
      this.showToast(err.message, "danger");
    }
  },

  setReplyTo(msgId, senderName, snippet) {
    this.activeReplyTo = {
      message_id: msgId,
      sender_name: senderName,
      snippet: snippet
    };

    document.getElementById("reply-sender-name").textContent = senderName;
    document.getElementById("reply-snippet-text").textContent = snippet;
    document.getElementById("active-reply-banner").classList.remove("hidden");
    document.getElementById("message-input").focus();
  },

  cancelReply() {
    this.activeReplyTo = null;
    document.getElementById("active-reply-banner").classList.add("hidden");
  },

  // =========================================================================
  // MESSAGE REQUESTS (Section 12)
  // =========================================================================

  async checkMessageRequests(isBackground = false) {
    try {
      const requests = await ChatService.getPendingRequests(this.currentUser._id);
      const banner = document.getElementById("message-requests-banner");
      const textEl = document.getElementById("requests-banner-text");

      if (requests.length > 0) {
        textEl.textContent = `Message Requests (${requests.length})`;
        banner.classList.remove("hidden");
      } else {
        banner.classList.add("hidden");
      }

      // If modal is currently open, re-render
      const modal = document.getElementById("requests-modal");
      if (!modal.classList.contains("hidden")) {
        this.renderMessageRequestsModal(requests);
      }
    } catch (e) {
      console.error("Error checking message requests:", e);
    }
  },

  renderMessageRequestsModal(requests) {
    const listEl = document.getElementById("incoming-requests-list");
    const emptyEl = document.getElementById("incoming-requests-empty");

    if (requests.length === 0) {
      listEl.innerHTML = "";
      emptyEl.classList.remove("hidden");
      return;
    }

    emptyEl.classList.add("hidden");
    let html = "";
    for (const req of requests) {
      const sender = req.sender;
      const snippet = req.last_message ? req.last_message.content : "Sent a message";
      html += `
        <div class="conv-item" style="border: 1px solid var(--border); border-radius: var(--radius-md); background: #ffffff;">
          <div class="avatar-wrap">
            <img class="avatar" src="${sender.avatar_url}" alt="${CryptoUtils.escapeHTML(sender.display_name)}">
          </div>
          <div class="conv-content">
            <div class="conv-name">${CryptoUtils.escapeHTML(sender.display_name)} <span style="font-size: 11px; font-weight: normal; color: var(--text-muted);">@${CryptoUtils.escapeHTML(sender.username)}</span></div>
            <div class="conv-snippet truncate" style="color: var(--text-main); font-weight: 500; margin: 4px 0;">"${CryptoUtils.escapeHTML(snippet)}"</div>
            <div style="display: flex; gap: 8px; margin-top: 6px;">
              <button class="btn btn-primary btn-sm btn-req-accept" data-conv-id="${req._id}">Accept</button>
              <button class="btn btn-secondary btn-sm btn-req-decline" data-conv-id="${req._id}">Decline</button>
              <button class="btn btn-danger btn-sm btn-req-block" data-user-id="${sender._id}">Block</button>
            </div>
          </div>
        </div>
      `;
    }
    listEl.innerHTML = html;
  },

  // =========================================================================
  // USER SEARCH (@username) (Section 7)
  // =========================================================================

  async handleUserSearch(query) {
    const listEl = document.getElementById("search-results-list");
    const emptyEl = document.getElementById("search-results-empty");

    if (!query || !query.trim()) {
      listEl.innerHTML = "";
      emptyEl.textContent = "Type a username to find people.";
      emptyEl.classList.remove("hidden");
      return;
    }

    try {
      const users = await UserService.searchUsers(query, this.currentUser._id);

      if (users.length === 0) {
        listEl.innerHTML = "";
        emptyEl.textContent = `No users found matching "${query}".`;
        emptyEl.classList.remove("hidden");
        return;
      }

      emptyEl.classList.add("hidden");
      let html = "";
      for (const u of users) {
        if (window.PresenceManager) {
          PresenceManager.cacheUserPresence(u._id, u.last_seen);
        }
        const presence = window.PresenceManager
          ? PresenceManager.getUserPresence(u._id, u.last_seen)
          : { isOnline: u.is_online, statusText: u.last_seen_text };
        const onlineClass = presence.isOnline ? "online" : "offline";

        html += `
          <div class="status-item-card" style="align-items: center;">
            <div class="avatar-wrap">
              <img class="avatar" src="${u.avatar_url}" alt="${CryptoUtils.escapeHTML(u.display_name)}">
              <div class="online-dot ${onlineClass}" data-presence-dot-user-id="${u._id}" data-last-seen-iso="${u.last_seen || ''}"></div>
            </div>
            <div class="status-item-content truncate">
              <div class="status-item-top">
                <span class="status-author-name truncate">${CryptoUtils.escapeHTML(u.display_name)}</span>
                <span class="status-time" data-presence-user-id="${u._id}" data-last-seen-iso="${u.last_seen || ''}">${presence.statusText}</span>
              </div>
              <div style="font-size: 12px; color: var(--text-muted);">@${CryptoUtils.escapeHTML(u.username)}</div>
              ${u.bio ? `<div class="truncate" style="font-size: 12px; color: var(--text-main); margin-top: 2px;">${CryptoUtils.escapeHTML(u.bio)}</div>` : ''}
              ${u.current_status ? `<div class="status-quote-box" style="margin-top: 6px; padding: 4px 8px; font-size: 11px;">"${CryptoUtils.escapeHTML(u.current_status)}"</div>` : ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              ${!u.is_self ? `
                <button class="btn btn-primary btn-sm btn-start-chat-with" data-user-id="${u._id}">Message</button>
                <button class="btn ${u.is_blocked ? 'btn-secondary' : 'btn-danger'} btn-sm btn-toggle-block" data-user-id="${u._id}" data-blocked="${u.is_blocked}">
                  ${u.is_blocked ? 'Unblock' : 'Block'}
                </button>
              ` : `<span class="badge badge-success">You</span>`}
            </div>
          </div>
        `;
      }
      listEl.innerHTML = html;
    } catch (e) {
      console.error("Search error:", e);
    }
  },

  // =========================================================================
  // BBM-STYLE STATUS SECTION (Section 17)
  // =========================================================================

  async loadStatusFeed() {
    try {
      const feedEl = document.getElementById("status-feed-list");
      const myAvatar = document.getElementById("status-my-avatar");
      const myStatusInput = document.getElementById("my-status-input");

      if (this.currentUser) {
        myAvatar.src = this.currentUser.avatar_url || "assets/default-avatar.svg";
        myStatusInput.value = this.currentUser.current_status || "";
      }

      const statuses = await StatusService.getAllStatuses(this.currentUser._id);

      if (statuses.length === 0) {
        feedEl.innerHTML = `<div class="form-help" style="text-align: center; padding: 16px;">No status updates yet. Share what you are doing!</div>`;
        return;
      }

      let html = "";
      for (const s of statuses) {
        html += `
          <div class="status-item-card">
            <div class="avatar-wrap">
              <img class="avatar" src="${s.avatar_url}" alt="${CryptoUtils.escapeHTML(s.display_name)}">
            </div>
            <div class="status-item-content">
              <div class="status-item-top">
                <span class="status-author-name">${CryptoUtils.escapeHTML(s.display_name)} ${s.is_self ? '<span class="badge badge-primary" style="font-size: 10px;">You</span>' : ''}</span>
                <span class="status-time">${s.time_ago}</span>
              </div>
              <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">@${CryptoUtils.escapeHTML(s.username)}</div>
              <div class="status-quote-box">"${CryptoUtils.escapeHTML(s.current_status)}"</div>
            </div>
          </div>
        `;
      }
      feedEl.innerHTML = html;
    } catch (e) {
      console.error("Status feed error:", e);
    }
  },

  async handleUpdateStatus() {
    const text = document.getElementById("my-status-input").value.trim();
    if (!text) {
      this.showToast("Please enter a status message.", "warning");
      return;
    }

    try {
      await StatusService.updateStatus(this.currentUser._id, text);
      this.currentUser.current_status = text;
      this.showToast("Status updated successfully! 🚀", "success");
      await this.loadStatusFeed();
    } catch (e) {
      this.showToast(e.message, "danger");
    }
  },

  // =========================================================================
  // SETTINGS & PROFILE MANAGEMENT (Section 8, 10, 11, 19)
  // =========================================================================

  async loadSettings() {
    if (!this.currentUser) return;

    // 1. Profile fields
    document.getElementById("settings-avatar-img").src = this.currentUser.avatar_url || "assets/default-avatar.svg";
    document.getElementById("settings-display-name").value = this.currentUser.display_name || "";
    document.getElementById("settings-bio").value = this.currentUser.bio || "";

    // 2. Username change quota & cooldown (Section 10)
    const quotaInfo = UserService.getUsernameChangeStatus(this.currentUser);
    const quotaBadge = document.getElementById("username-quota-badge");
    quotaBadge.textContent = quotaInfo.message;
    quotaBadge.className = `username-status-badge ${quotaInfo.canChange ? 'badge-available' : 'badge-cooldown'}`;

    // 3. Privacy settings (Section 11)
    const privacy = await SettingsService.getPrivacySettings(this.currentUser._id);
    document.getElementById("setting-who-can-find").value = privacy.who_can_find_me;
    document.getElementById("setting-allow-requests").checked = privacy.allow_message_requests;

    // 4. Blocked accounts list (Section 18)
    await this.loadBlockedUsers();
  },

  async loadBlockedUsers() {
    try {
      const blocked = await UserService.getBlockedUsers(this.currentUser._id);
      const listEl = document.getElementById("blocked-users-list");
      const emptyEl = document.getElementById("blocked-users-empty");

      if (blocked.length === 0) {
        listEl.innerHTML = "";
        emptyEl.classList.remove("hidden");
        return;
      }

      emptyEl.classList.add("hidden");
      let html = "";
      for (const u of blocked) {
        html += `
          <div class="blocked-item">
            <div class="blocked-user-info">
              <img class="avatar avatar-sm" src="${u.avatar_url}" alt="${CryptoUtils.escapeHTML(u.display_name)}">
              <div>
                <div style="font-size: 13px; font-weight: 700;">${CryptoUtils.escapeHTML(u.display_name)}</div>
                <div style="font-size: 11px; color: var(--text-muted);">@${CryptoUtils.escapeHTML(u.username)}</div>
              </div>
            </div>
            <button class="btn btn-secondary btn-sm btn-unblock-user" data-user-id="${u._id}">Unblock</button>
          </div>
        `;
      }
      listEl.innerHTML = html;
    } catch (e) {
      console.error("Error loading blocked users:", e);
    }
  },

  async handleSaveProfile() {
    const displayName = document.getElementById("settings-display-name").value.trim();
    const bio = document.getElementById("settings-bio").value.trim();

    try {
      const updated = await UserService.updateProfile(this.currentUser._id, { displayName, bio });
      this.currentUser = AuthService.sanitizeUser(updated);
      this.renderSidebarUser();
      this.showToast("Profile saved successfully!", "success");
    } catch (e) {
      this.showToast(e.message, "danger");
    }
  },

  async handleAvatarUpload(file) {
    try {
      const dataUrl = await UserService.uploadAvatar(this.currentUser._id, file);
      this.currentUser.avatar_url = dataUrl;
      document.getElementById("settings-avatar-img").src = dataUrl;
      this.renderSidebarUser();
      this.showToast("Profile picture updated!", "success");
    } catch (e) {
      this.showToast(e.message, "danger");
    }
  },

  async handleChangeUsername() {
    const input = document.getElementById("settings-username-input");
    const newUsername = input.value.trim();
    if (!newUsername) {
      this.showToast("Please enter a new username.", "warning");
      return;
    }

    try {
      const updated = await UserService.changeUsername(this.currentUser._id, newUsername);
      this.currentUser = AuthService.sanitizeUser(updated);
      this.renderSidebarUser();
      input.value = "";
      this.loadSettings();
      this.showToast(`Username changed to @${this.currentUser.username}!`, "success");
    } catch (e) {
      this.showToast(e.message, "danger");
    }
  },

  async handlePrivacyUpdate() {
    const whoCanFindMe = document.getElementById("setting-who-can-find").value;
    const allowMessageRequests = document.getElementById("setting-allow-requests").checked;

    try {
      await SettingsService.updatePrivacySettings(this.currentUser._id, {
        whoCanFindMe,
        allowMessageRequests
      });
      this.showToast("Privacy settings updated.", "success");
    } catch (e) {
      this.showToast(e.message, "danger");
    }
  },

  // =========================================================================
  // TOAST NOTIFICATIONS & ALERTS
  // =========================================================================

  showToast(message, type = "info") {
    const existing = document.querySelector(".toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    let icon = "ℹ️";
    if (type === "success") icon = "✅";
    if (type === "danger") icon = "⚠️";
    if (type === "warning") icon = "⚠️";

    toast.innerHTML = `<span>${icon}</span> <span>${CryptoUtils.escapeHTML(message)}</span>`;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transition = "opacity 0.3s ease";
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  },

  // =========================================================================
  // EVENT BINDINGS
  // =========================================================================

  bindEvents() {
    // Landing page & Auth buttons
    document.getElementById("btn-open-login").addEventListener("click", () => this.openModal("login-modal"));
    document.getElementById("hero-btn-login").addEventListener("click", () => this.openModal("login-modal"));
    document.getElementById("btn-open-register").addEventListener("click", () => this.openRegisterModal());
    document.getElementById("hero-btn-register").addEventListener("click", () => this.openRegisterModal());

    // Switch between Login and Register inside modals
    document.getElementById("link-switch-to-register").addEventListener("click", (e) => {
      e.preventDefault();
      this.closeModal("login-modal");
      this.openRegisterModal();
    });
    document.getElementById("link-switch-to-login").addEventListener("click", (e) => {
      e.preventDefault();
      this.closeModal("register-modal");
      this.openModal("login-modal");
    });

    // Close modals
    document.querySelectorAll("[data-close-modal]").forEach(btn => {
      btn.addEventListener("click", () => {
        this.closeModal(btn.getAttribute("data-close-modal"));
      });
    });

    // Refresh CAPTCHA
    document.getElementById("btn-refresh-captcha").addEventListener("click", () => {
      this.refreshCaptcha();
    });

    // Login Form Submit
    document.getElementById("login-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const userField = document.getElementById("login-username").value;
      const passField = document.getElementById("login-password").value;
      const alertEl = document.getElementById("login-alert");

      try {
        alertEl.classList.add("hidden");
        const user = await AuthService.login(userField, passField);
        this.currentUser = user;
        this.closeModal("login-modal");
        this.showMainApp();
        this.showToast(`Welcome back, ${user.display_name}!`, "success");
      } catch (err) {
        alertEl.textContent = err.message;
        alertEl.classList.remove("hidden");
      }
    });

    // Register Form Submit
    document.getElementById("register-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const username = document.getElementById("reg-username").value;
      const displayName = document.getElementById("reg-display-name").value;
      const password = document.getElementById("reg-password").value;
      const confirmPassword = document.getElementById("reg-confirm-password").value;
      const captchaAnswer = document.getElementById("reg-captcha-answer").value;
      const alertEl = document.getElementById("register-alert");

      try {
        alertEl.classList.add("hidden");
        const user = await AuthService.register({
          username,
          displayName,
          password,
          confirmPassword,
          captchaAnswer
        });

        this.currentUser = user;
        this.closeModal("register-modal");
        this.showMainApp();
        this.showToast(`Account created! Welcome to SPOTon Chat, @${user.username}! 🎉`, "success");
      } catch (err) {
        alertEl.textContent = err.message;
        alertEl.classList.remove("hidden");
        this.refreshCaptcha();
      }
    });

    // Navigation Tabs (Chats | Status | Me)
    document.querySelectorAll(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const tabName = btn.getAttribute("data-tab");
        document.getElementById("tab-panel-chats").classList.toggle("hidden", tabName !== "chats");
        document.getElementById("tab-panel-status").classList.toggle("hidden", tabName !== "status");
        document.getElementById("tab-panel-me").classList.toggle("hidden", tabName !== "me");

        if (tabName === "status") this.loadStatusFeed();
        if (tabName === "me") this.loadSettings();
      });
    });

    // Sidebar user profile click -> jump to "Me" tab
    document.getElementById("sidebar-user-profile-btn").addEventListener("click", () => {
      document.querySelector(`.tab-btn[data-tab="me"]`).click();
    });

    // Search Buttons
    const openSearch = () => {
      this.openModal("search-modal");
      document.getElementById("modal-search-input").value = "";
      document.getElementById("modal-search-input").focus();
      this.handleUserSearch("");
    };

    document.getElementById("btn-open-search").addEventListener("click", openSearch);
    document.getElementById("quick-search-input").addEventListener("focus", openSearch);
    document.getElementById("btn-start-first-chat").addEventListener("click", openSearch);

    // Modal Search Input Handler
    document.getElementById("modal-search-input").addEventListener("input", (e) => {
      this.handleUserSearch(e.target.value);
    });

    // Search Result Actions (Delegated)
    document.getElementById("search-results-list").addEventListener("click", async (e) => {
      const msgBtn = e.target.closest(".btn-start-chat-with");
      if (msgBtn) {
        const targetUserId = msgBtn.getAttribute("data-user-id");
        try {
          const conv = await ChatService.getOrCreateConversation(this.currentUser._id, targetUserId);
          this.closeModal("search-modal");
          document.querySelector(`.tab-btn[data-tab="chats"]`).click();
          await this.loadConversations();
          await this.selectConversation(conv._id);
        } catch (err) {
          this.showToast(err.message, "danger");
        }
        return;
      }

      const blockBtn = e.target.closest(".btn-toggle-block");
      if (blockBtn) {
        const targetUserId = blockBtn.getAttribute("data-user-id");
        const isBlocked = blockBtn.getAttribute("data-blocked") === "true";
        try {
          if (isBlocked) {
            await UserService.unblockUser(this.currentUser._id, targetUserId);
            this.showToast("User unblocked.", "success");
          } else {
            await UserService.blockUser(this.currentUser._id, targetUserId);
            this.showToast("User blocked.", "warning");
          }
          this.handleUserSearch(document.getElementById("modal-search-input").value);
        } catch (err) {
          this.showToast(err.message, "danger");
        }
      }
    });

    // Select Conversation from list
    document.getElementById("conversations-list").addEventListener("click", (e) => {
      const item = e.target.closest(".conv-item");
      if (item) {
        const convId = item.getAttribute("data-conv-id");
        this.selectConversation(convId);
      }
    });

    // Message Requests Banner click
    document.getElementById("message-requests-banner").addEventListener("click", async () => {
      this.openModal("requests-modal");
      const requests = await ChatService.getPendingRequests(this.currentUser._id);
      this.renderMessageRequestsModal(requests);
    });

    // Request Modal Actions (Accept, Decline, Block)
    document.getElementById("incoming-requests-list").addEventListener("click", async (e) => {
      const acceptBtn = e.target.closest(".btn-req-accept");
      if (acceptBtn) {
        const convId = acceptBtn.getAttribute("data-conv-id");
        await ChatService.acceptRequest(convId, this.currentUser._id);
        this.closeModal("requests-modal");
        await this.checkMessageRequests();
        await this.loadConversations();
        await this.selectConversation(convId);
        this.showToast("Message request accepted! You can now chat freely.", "success");
        return;
      }

      const declineBtn = e.target.closest(".btn-req-decline");
      if (declineBtn) {
        const convId = declineBtn.getAttribute("data-conv-id");
        await ChatService.declineRequest(convId, this.currentUser._id);
        await this.checkMessageRequests();
        await this.loadConversations();
        this.showToast("Message request declined.", "info");
        return;
      }

      const blockBtn = e.target.closest(".btn-req-block");
      if (blockBtn) {
        const userId = blockBtn.getAttribute("data-user-id");
        await UserService.blockUser(this.currentUser._id, userId);
        this.closeModal("requests-modal");
        await this.checkMessageRequests();
        await this.loadConversations();
        this.showToast("User blocked.", "warning");
        return;
      }
    });

    // Active Chat Banner Request Actions (Accept / Decline directly from chat pane)
    document.getElementById("btn-accept-request").addEventListener("click", async () => {
      if (!this.activeConversation) return;
      await ChatService.acceptRequest(this.activeConversation._id, this.currentUser._id);
      this.activeConversation.status = "active";
      this.updateRequestBanner(this.activeConversation);
      await this.loadConversations(true);
      this.showToast("Conversation accepted!", "success");
    });

    document.getElementById("btn-decline-request").addEventListener("click", async () => {
      if (!this.activeConversation) return;
      await ChatService.declineRequest(this.activeConversation._id, this.currentUser._id);
      this.activeConversation.status = "declined";
      this.updateRequestBanner(this.activeConversation);
      await this.loadConversations(true);
      this.showToast("Conversation declined.", "info");
    });

    // Chat Composer Form Submit
    document.getElementById("chat-composer-form").addEventListener("submit", (e) => {
      e.preventDefault();
      this.handleSendMessage();
    });

    // Cancel Reply Button
    document.getElementById("btn-cancel-reply").addEventListener("click", () => {
      this.cancelReply();
    });

    // Reply Button on Message Bubble (Delegated)
    document.getElementById("chat-messages-container").addEventListener("click", (e) => {
      const replyBtn = e.target.closest(".btn-reply-msg");
      if (replyBtn) {
        const msgId = replyBtn.getAttribute("data-msg-id");
        const senderName = replyBtn.getAttribute("data-sender-name");
        const snippet = replyBtn.getAttribute("data-snippet");
        this.setReplyTo(msgId, senderName, snippet);
      }
    });

    // Chat Header: Three-Dot Dropdown Menu (Update 4)
    const btnChatMenu = document.getElementById("btn-chat-menu");
    const dropdownMenu = document.getElementById("chat-dropdown-menu");
    if (btnChatMenu && dropdownMenu) {
      btnChatMenu.addEventListener("click", (e) => {
        e.stopPropagation();
        dropdownMenu.classList.toggle("hidden");
        btnChatMenu.setAttribute("aria-expanded", !dropdownMenu.classList.contains("hidden"));
      });

      document.addEventListener("click", (e) => {
        if (!e.target.closest(".chat-menu-wrap")) {
          dropdownMenu.classList.add("hidden");
          btnChatMenu.setAttribute("aria-expanded", "false");
        }
      });
    }

    // Three-Dot Menu Action: Clear Messages
    const btnClearChat = document.getElementById("menu-item-clear-chat");
    if (btnClearChat) {
      btnClearChat.addEventListener("click", () => {
        dropdownMenu?.classList.add("hidden");
        const container = document.getElementById("chat-messages-container");
        if (container) {
          container.innerHTML = `
            <div class="chat-empty-state" style="padding: 40px 0;">
              <p style="font-size: 13px; color: var(--text-muted);">Messages cleared from view.</p>
            </div>`;
          this.showToast("Chat view cleared.", "info");
        }
      });
    }

    // Three-Dot Menu Action: Toggle Block (Opens Modal)
    const menuToggleBlock = document.getElementById("menu-item-toggle-block");
    if (menuToggleBlock) {
      menuToggleBlock.addEventListener("click", () => {
        dropdownMenu?.classList.add("hidden");
        if (!this.activePartner) return;
        const action = menuToggleBlock.getAttribute("data-action");
        if (action === "unblock") {
          this.openUnblockConfirmModal(this.activePartner);
        } else {
          this.openBlockConfirmModal(this.activePartner);
        }
      });
    }

    // In-Chat Banner Action: Unblock Button (Opens Modal)
    const btnUnblockBanner = document.getElementById("btn-unblock-from-banner");
    if (btnUnblockBanner) {
      btnUnblockBanner.addEventListener("click", () => {
        if (this.activePartner) {
          this.openUnblockConfirmModal(this.activePartner);
        }
      });
    }

    // Confirm Block in Modal (Update 7)
    const btnConfirmBlock = document.getElementById("btn-confirm-block");
    if (btnConfirmBlock) {
      btnConfirmBlock.addEventListener("click", async () => {
        if (!this.activePartner) return;
        const partnerId = this.activePartner.id || this.activePartner._id;
        try {
          await UserService.blockUser(this.currentUser._id, partnerId);
          this.closeModal("block-confirm-modal");
          this.showToast(`Blocked ${this.activePartner.display_name || this.activePartner.username}.`, "warning");

          // Keep chat open! Update in-place state (Update 3)
          this.updateBlockStateUI({ is_blocked: true, is_blocked_by_me: true, is_blocked_by_partner: false }, this.activePartner);
          await this.loadConversations(true);
        } catch (e) {
          this.showToast(e.message, "danger");
        }
      });
    }

    // Confirm Unblock in Modal (Update 7)
    const btnConfirmUnblock = document.getElementById("btn-confirm-unblock");
    if (btnConfirmUnblock) {
      btnConfirmUnblock.addEventListener("click", async () => {
        if (!this.activePartner) return;
        const partnerId = this.activePartner.id || this.activePartner._id;
        try {
          await UserService.unblockUser(this.currentUser._id, partnerId);
          this.closeModal("unblock-confirm-modal");
          this.showToast(`Unblocked ${this.activePartner.display_name || this.activePartner.username}.`, "success");

          // Keep chat open! Update in-place state
          this.updateBlockStateUI({ is_blocked: false, is_blocked_by_me: false, is_blocked_by_partner: false }, this.activePartner);
          await this.loadConversations(true);
        } catch (e) {
          this.showToast(e.message, "danger");
        }
      });
    }

    // Mobile / Minimized UI Back Button (Return to Home / Chats)
    const mobileBackBtn = document.getElementById("btn-mobile-back");
    if (mobileBackBtn) {
      mobileBackBtn.addEventListener("click", () => {
        // 1. Hide full-screen chat overlay on mobile / minimized window
        const chatArea = document.querySelector(".app-chat-area");
        if (chatArea) {
          chatArea.classList.remove("mobile-visible");
        }

        // 2. Clear active conversation selection and highlight
        this.activeConversation = null;
        this.activePartner = null;
        document.querySelectorAll(".conv-item").forEach(el => el.classList.remove("active"));

        // 3. Reset chat pane to placeholder state
        const activeWindow = document.getElementById("active-chat-window");
        const placeholder = document.getElementById("chat-placeholder");
        if (activeWindow) activeWindow.classList.add("hidden");
        if (placeholder) placeholder.classList.remove("hidden");

        // 4. Ensure user is viewing the Chats tab
        const chatsTabBtn = document.querySelector('.tab-btn[data-tab="chats"]');
        if (chatsTabBtn && !chatsTabBtn.classList.contains("active")) {
          chatsTabBtn.click();
        }
      });
    }

    // Status Tab: Quick Emoji Buttons
    document.querySelectorAll(".emoji-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const emoji = btn.getAttribute("data-emoji");
        const input = document.getElementById("my-status-input");
        input.value += emoji;
        input.focus();
      });
    });

    // Status Tab: Update Status
    document.getElementById("btn-save-status").addEventListener("click", () => {
      this.handleUpdateStatus();
    });

    // Settings Tab: Avatar Upload
    const fileInput = document.getElementById("avatar-file-input");
    document.getElementById("btn-trigger-upload").addEventListener("click", () => fileInput.click());
    document.getElementById("avatar-preview-container").addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        this.handleAvatarUpload(file);
      }
    });

    // Settings Tab: Save Profile
    document.getElementById("btn-save-profile").addEventListener("click", () => {
      this.handleSaveProfile();
    });

    // Settings Tab: Change Username
    document.getElementById("btn-save-username").addEventListener("click", () => {
      this.handleChangeUsername();
    });

    // Settings Tab: Privacy Settings
    document.getElementById("setting-who-can-find").addEventListener("change", () => this.handlePrivacyUpdate());
    document.getElementById("setting-allow-requests").addEventListener("change", () => this.handlePrivacyUpdate());

    // Settings Tab: Unblock User (Delegated)
    document.getElementById("blocked-users-list").addEventListener("click", async (e) => {
      const unblockBtn = e.target.closest(".btn-unblock-user");
      if (unblockBtn) {
        const userId = unblockBtn.getAttribute("data-user-id");
        await UserService.unblockUser(this.currentUser._id, userId);
        this.showToast("User unblocked.", "success");
        await this.loadBlockedUsers();
        if (this.activePartner && (this.activePartner.id === userId || this.activePartner._id === userId)) {
          this.updateBlockStateUI({ is_blocked: false, is_blocked_by_me: false, is_blocked_by_partner: false }, this.activePartner);
        }
        await this.loadConversations(true);
      }
    });

    // Settings Tab: Log Out
    document.getElementById("btn-logout").addEventListener("click", async () => {
      if (confirm("Are you sure you want to log out?")) {
        if (window.PresenceManager) {
          PresenceManager.destroy();
        }
        await AuthService.logout();
        this.currentUser = null;
        this.activeConversation = null;
        this.activePartner = null;
        this.showLandingPage();
        this.showToast("You have been logged out.", "info");
      }
    });
  },

  // =========================================================================
  // MODAL HELPERS
  // =========================================================================

  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove("hidden");
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add("hidden");
  },

  openRegisterModal() {
    this.refreshCaptcha();
    this.openModal("register-modal");
    document.getElementById("reg-username").focus();
  },

  refreshCaptcha() {
    const challenge = AuthService.generateCaptcha();
    document.getElementById("captcha-question-badge").textContent = challenge;
    document.getElementById("reg-captcha-answer").value = "";
  }
};

// Initialize on DOMContentLoaded
document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
