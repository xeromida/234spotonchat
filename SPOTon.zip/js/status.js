/**
 * SPOTon Chat - BBM-Style Status Service (Supabase Edition)
 * 
 * Manages personal status updates and chronological feed using
 * Supabase 'profiles' and 'blocks' tables.
 */

const StatusService = {
  /**
   * Update the user's personal status in Supabase profiles table
   */
  async updateStatus(userId, statusText) {
    if (!statusText || !statusText.trim()) {
      throw new Error("Status text cannot be empty.");
    }

    const cleanText = statusText.trim();
    if (cleanText.length > 140) {
      throw new Error("Status must be 140 characters or less.");
    }

    const nowIso = new Date().toISOString();

    const { error } = await window.supabaseClient
      .from("profiles")
      .update({
        current_status: cleanText,
        status_updated_at: nowIso
      })
      .eq("id", userId);

    if (error) {
      throw new Error(error.message || "Failed to update status.");
    }

    return {
      current_status: cleanText,
      status_updated_at: nowIso
    };
  },

  /**
   * Retrieves all users' statuses, sorted by update recency
   */
  async getAllStatuses(currentUserId) {
    const { data: users, error } = await window.supabaseClient
      .from("profiles")
      .select("*")
      .order("status_updated_at", { ascending: false });

    if (error || !users) return [];

    // Query blocks
    const { data: myBlocks } = await window.supabaseClient
      .from("blocks")
      .select("blocked_id")
      .eq("blocker_id", currentUserId);

    const { data: blockedByOthers } = await window.supabaseClient
      .from("blocks")
      .select("blocker_id")
      .eq("blocked_id", currentUserId);

    const excludedIds = new Set([
      ...(myBlocks || []).map(b => b.blocked_id),
      ...(blockedByOthers || []).map(b => b.blocker_id)
    ]);

    const statuses = [];
    for (const user of users) {
      if (excludedIds.has(user.id)) continue;
      if (!user.current_status) continue;

      statuses.push({
        _id: user.id,
        username: user.username,
        display_name: user.display_name,
        avatar_url: user.avatar_url || "assets/default-avatar.svg",
        current_status: user.current_status,
        status_updated_at: user.status_updated_at,
        time_ago: this.formatTimeAgo(user.status_updated_at),
        is_self: user.id === currentUserId
      });
    }

    return statuses;
  },

  /**
   * Helper to format relative time
   */
  formatTimeAgo(isoString) {
    if (!isoString) return "Just now";
    const diffMs = Date.now() - new Date(isoString).getTime();
    const minutes = Math.floor(diffMs / 60000);
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }
};

window.StatusService = StatusService;
