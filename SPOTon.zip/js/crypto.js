/**
 * SPOTon Chat - Cryptography & Security Utilities
 * 
 * Uses the browser's native Web Crypto API (SubtleCrypto) to securely hash
 * passwords with PBKDF2 (SHA-256) and cryptographically secure random salts.
 * No plaintext passwords are ever stored.
 */

const CryptoUtils = {
  /**
   * Generates a 24-character hexadecimal MongoDB ObjectId string.
   * Format: 4-byte timestamp + 5-byte random + 3-byte counter
   */
  generateObjectId() {
    const timestamp = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
    const randomHex = Array.from(window.crypto.getRandomValues(new Uint8Array(5)))
      .map(b => b.toString(16).padStart(2, '0')).join('');
    const counterHex = Array.from(window.crypto.getRandomValues(new Uint8Array(3)))
      .map(b => b.toString(16).padStart(2, '0')).join('');
    return timestamp + randomHex + counterHex;
  },

  /**
   * Generates a secure random session token.
   */
  generateToken() {
    const array = new Uint8Array(32);
    window.crypto.getRandomValues(array);
    return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  /**
   * Converts a string to ArrayBuffer (UTF-8)
   */
  stringToBuffer(str) {
    return new TextEncoder().encode(str);
  },

  /**
   * Converts an ArrayBuffer to a hex string
   */
  bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer))
      .map(b => b.toString(16).padStart(2, '0')).join('');
  },

  /**
   * Converts a hex string to ArrayBuffer
   */
  hexToBuffer(hex) {
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) {
      bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
    }
    return bytes.buffer;
  },

  /**
   * Hashes a password using PBKDF2 (SHA-256) with a salt.
   * @param {string} password - The plain password
   * @param {string} [existingSaltHex] - Optional existing salt hex for verification
   * @returns {Promise<string>} Format: "$pbkdf2$iterations$saltHex$hashHex"
   */
  async hashPassword(password, existingSaltHex = null) {
    const iterations = 100000;
    let saltBuffer;

    if (existingSaltHex) {
      saltBuffer = this.hexToBuffer(existingSaltHex);
    } else {
      const salt = new Uint8Array(16);
      window.crypto.getRandomValues(salt);
      saltBuffer = salt.buffer;
    }

    const keyMaterial = await window.crypto.subtle.importKey(
      "raw",
      this.stringToBuffer(password),
      { name: "PBKDF2" },
      false,
      ["deriveBits", "deriveKey"]
    );

    const derivedKey = await window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: saltBuffer,
        iterations: iterations,
        hash: "SHA-256"
      },
      keyMaterial,
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt", "decrypt"]
    );

    const exportedRaw = await window.crypto.subtle.exportKey("raw", derivedKey);
    const hashHex = this.bufferToHex(exportedRaw);
    const saltHex = this.bufferToHex(saltBuffer);

    return `$pbkdf2$${iterations}$${saltHex}$${hashHex}`;
  },

  /**
   * Verifies whether a plain password matches the stored hash format.
   * @param {string} password - The plain password to test
   * @param {string} storedHash - Stored hash string
   * @returns {Promise<boolean>}
   */
  async verifyPassword(password, storedHash) {
    try {
      if (!storedHash || !storedHash.startsWith("$pbkdf2$")) {
        return false;
      }
      const parts = storedHash.split("$");
      // parts[0] is "", parts[1] is "pbkdf2", parts[2] is iterations, parts[3] is saltHex, parts[4] is hashHex
      const saltHex = parts[3];
      const computedHash = await this.hashPassword(password, saltHex);
      return computedHash === storedHash;
    } catch (e) {
      console.error("Password verification error:", e);
      return false;
    }
  },

  /**
   * Escapes HTML to prevent Cross-Site Scripting (XSS).
   * @param {string} text - Raw user input
   * @returns {string} Sanitized text
   */
  escapeHTML(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
};

window.CryptoUtils = CryptoUtils;
